#include <stdio.h>
void delay(unsigned short wait);
//
void delay( unsigned short wait)
{
     while (wait) {
           wait = wait -1;
     }
}
//
int main()
{
  int i;
  printf("\n\r      DE0-Nano RL_Emulator : UART-Test-Loop    \n\r ");
  while(1){
	for (i = 0; i < 200; i++ )  {
		  delay(10000);                // wait
	      printf("\n\r Count &  Hallo vom UART @ 19200 Baud    %d" , i);
	}
  }
  return 0;
}
