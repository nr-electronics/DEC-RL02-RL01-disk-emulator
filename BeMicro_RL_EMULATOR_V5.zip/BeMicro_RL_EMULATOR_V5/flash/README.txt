         Instructions for loading & flashing  DE0-Nano-Board
            running the RL01/RL02 disk simulator on it


-  Make sure, your USB connection to the DE1-Board is working.
-  DE0-Board: SW2 = ON,  Serial-Speed =  19200 Baud
 	 
-  In Windows: Start the Nios2 Command Shell , EDS 11.1sp2 [GCC 4]
 	          ( location:  \altera\11.1sp2\nios2eds )                  
-  Navigate to the unziped flash directory with command cd. 
-  A ls command should get following result:
	  flash_example.txt  in_RAM            myelf.flash  myload.sh
 	  in_EPCS            load_example.txt  myflash.sh   mysof.flash
-  If You want to load the design to RAM, use: ./myload.sh
     > Example/reference:  load_example.txt 
-  If You want to flash the design, make it permanent, use: ./myflash.sh
     > Example/reference:  flash_example.txt 

        Feedback, if You want:  Reinhard.Heuberger@pdp11gy.com



Note ! flashing with Altera Nios2 Command Shell Version 16.1 NOT possible ( BUG )
     *****  Use Altera Nios2 Command Shell [GCC 4] Version 15.1, Build 185 *****
