#!/bin/sh
#
#   Copyright (C) 2013 by Reinhard Heuberger , www.pdp11gy.com
#
echo ""
echo ""
echo "         ************************************* "
echo "         ***** Make the design permanent ***** "
echo "         ************************************* "
echo "         **** flash the design into EPCS **** "
echo ""
echo "         1) load a NIOS-II processor ...."

jtagconfig

nios2-configure-sof ./in_EPCS/RL_emulator.sof
echo ""
echo "         2) start flashing...."
#
sof2flash --epcs --input="./in_EPCS/RL_emulator.sof" --output="./mysof.flash" --verbose 
echo ">> sof2flash done"
#
#
elf2flash --epcs --base=0x0 --input="./in_EPCS/SoC_NIOS_UART.elf" --output="./myelf.flash" --after="./mysof.flash" --verbose 
echo ">> elf2flash done"
#
nios2-flash-programmer --base=0x80009000 --epcs --program --verbose --accept-bad-sysid --program "./mysof.flash" --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' 
#
nios2-flash-programmer --base=0x80009000 --epcs --program --verbose --accept-bad-sysid --device=1 --instance=0 '--cable=USB-Blaster on localhost [USB-0]' --program "./myelf.flash"  
#
#
echo ""
echo "                     finished "
echo "           re-power the DE0-Nano SoC Board !"
echo ""
