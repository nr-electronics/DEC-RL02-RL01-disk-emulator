/*
 * system.h - SOPC Builder system and BSP software package information
 *
 * Machine generated for CPU 'nios2_gen2_0' in SOPC Builder design 'RL_system'
 * SOPC Builder design path: ../../RL_system.sopcinfo
 *
 * Generated: Sat Sep 30 14:55:07 CEST 2017
 */

/*
 * DO NOT MODIFY THIS FILE
 *
 * Changing this file will have subtle consequences
 * which will almost certainly lead to a nonfunctioning
 * system. If you do modify this file, be aware that your
 * changes will be overwritten and lost when this file
 * is generated again.
 *
 * DO NOT MODIFY THIS FILE
 */

/*
 * License Agreement
 *
 * Copyright (c) 2008
 * Altera Corporation, San Jose, California, USA.
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * This agreement shall be governed in all respects by the laws of the State
 * of California and by the laws of the United States of America.
 */

#ifndef __SYSTEM_H_
#define __SYSTEM_H_

/* Include definitions from linker script generator */
#include "linker.h"


/*
 * CPU configuration
 *
 */

#define ALT_CPU_ARCHITECTURE "altera_nios2_gen2"
#define ALT_CPU_BIG_ENDIAN 0
#define ALT_CPU_BREAK_ADDR 0x80009820
#define ALT_CPU_CPU_ARCH_NIOS2_R1
#define ALT_CPU_CPU_FREQ 98412698u
#define ALT_CPU_CPU_ID_SIZE 1
#define ALT_CPU_CPU_ID_VALUE 0x00000000
#define ALT_CPU_CPU_IMPLEMENTATION "tiny"
#define ALT_CPU_DATA_ADDR_WIDTH 0x20
#define ALT_CPU_DCACHE_LINE_SIZE 0
#define ALT_CPU_DCACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_DCACHE_SIZE 0
#define ALT_CPU_EXCEPTION_ADDR 0x90040020
#define ALT_CPU_FLASH_ACCELERATOR_LINES 0
#define ALT_CPU_FLASH_ACCELERATOR_LINE_SIZE 0
#define ALT_CPU_FLUSHDA_SUPPORTED
#define ALT_CPU_FREQ 98412698
#define ALT_CPU_HARDWARE_DIVIDE_PRESENT 0
#define ALT_CPU_HARDWARE_MULTIPLY_PRESENT 0
#define ALT_CPU_HARDWARE_MULX_PRESENT 0
#define ALT_CPU_HAS_DEBUG_CORE 1
#define ALT_CPU_HAS_DEBUG_STUB
#define ALT_CPU_HAS_ILLEGAL_INSTRUCTION_EXCEPTION
#define ALT_CPU_HAS_JMPI_INSTRUCTION
#define ALT_CPU_ICACHE_LINE_SIZE 0
#define ALT_CPU_ICACHE_LINE_SIZE_LOG2 0
#define ALT_CPU_ICACHE_SIZE 0
#define ALT_CPU_INST_ADDR_WIDTH 0x20
#define ALT_CPU_NAME "nios2_gen2_0"
#define ALT_CPU_OCI_VERSION 1
#define ALT_CPU_RESET_ADDR 0x90040000


/*
 * CPU configuration (with legacy prefix - don't use these anymore)
 *
 */

#define NIOS2_BIG_ENDIAN 0
#define NIOS2_BREAK_ADDR 0x80009820
#define NIOS2_CPU_ARCH_NIOS2_R1
#define NIOS2_CPU_FREQ 98412698u
#define NIOS2_CPU_ID_SIZE 1
#define NIOS2_CPU_ID_VALUE 0x00000000
#define NIOS2_CPU_IMPLEMENTATION "tiny"
#define NIOS2_DATA_ADDR_WIDTH 0x20
#define NIOS2_DCACHE_LINE_SIZE 0
#define NIOS2_DCACHE_LINE_SIZE_LOG2 0
#define NIOS2_DCACHE_SIZE 0
#define NIOS2_EXCEPTION_ADDR 0x90040020
#define NIOS2_FLASH_ACCELERATOR_LINES 0
#define NIOS2_FLASH_ACCELERATOR_LINE_SIZE 0
#define NIOS2_FLUSHDA_SUPPORTED
#define NIOS2_HARDWARE_DIVIDE_PRESENT 0
#define NIOS2_HARDWARE_MULTIPLY_PRESENT 0
#define NIOS2_HARDWARE_MULX_PRESENT 0
#define NIOS2_HAS_DEBUG_CORE 1
#define NIOS2_HAS_DEBUG_STUB
#define NIOS2_HAS_ILLEGAL_INSTRUCTION_EXCEPTION
#define NIOS2_HAS_JMPI_INSTRUCTION
#define NIOS2_ICACHE_LINE_SIZE 0
#define NIOS2_ICACHE_LINE_SIZE_LOG2 0
#define NIOS2_ICACHE_SIZE 0
#define NIOS2_INST_ADDR_WIDTH 0x20
#define NIOS2_OCI_VERSION 1
#define NIOS2_RESET_ADDR 0x90040000


/*
 * DPR configuration
 *
 */

#define ALT_MODULE_CLASS_DPR altera_avalon_onchip_memory2
#define DPR_ALLOW_IN_SYSTEM_MEMORY_CONTENT_EDITOR 0
#define DPR_ALLOW_MRAM_SIM_CONTENTS_ONLY_FILE 0
#define DPR_BASE 0x90000000
#define DPR_CONTENTS_INFO ""
#define DPR_DUAL_PORT 1
#define DPR_GUI_RAM_BLOCK_TYPE "AUTO"
#define DPR_INIT_CONTENTS_FILE "RL_system_DPR"
#define DPR_INIT_MEM_CONTENT 1
#define DPR_INSTANCE_ID "NONE"
#define DPR_IRQ -1
#define DPR_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DPR_NAME "/dev/DPR"
#define DPR_NON_DEFAULT_INIT_FILE_ENABLED 0
#define DPR_RAM_BLOCK_TYPE "AUTO"
#define DPR_READ_DURING_WRITE_MODE "DONT_CARE"
#define DPR_SINGLE_CLOCK_OP 0
#define DPR_SIZE_MULTIPLE 1
#define DPR_SIZE_VALUE 11520
#define DPR_SPAN 11520
#define DPR_TYPE "altera_avalon_onchip_memory2"
#define DPR_WRITABLE 1


/*
 * Define for each module class mastered by the CPU
 *
 */

#define __ALTERA_AVALON_EPCS_FLASH_CONTROLLER
#define __ALTERA_AVALON_ONCHIP_MEMORY2
#define __ALTERA_AVALON_PIO
#define __ALTERA_AVALON_TIMER
#define __ALTERA_AVALON_UART
#define __ALTERA_NIOS2_GEN2
#define __DIRECT_WINDOW_BRIDGE


/*
 * System configuration
 *
 */

#define ALT_DEVICE_FAMILY "Cyclone V"
#define ALT_ENHANCED_INTERRUPT_API_PRESENT
#define ALT_IRQ_BASE NULL
#define ALT_LOG_PORT "/dev/null"
#define ALT_LOG_PORT_BASE 0x0
#define ALT_LOG_PORT_DEV null
#define ALT_LOG_PORT_TYPE ""
#define ALT_NUM_EXTERNAL_INTERRUPT_CONTROLLERS 0
#define ALT_NUM_INTERNAL_INTERRUPT_CONTROLLERS 1
#define ALT_NUM_INTERRUPT_CONTROLLERS 1
#define ALT_STDERR "/dev/uart_0"
#define ALT_STDERR_BASE 0x8000a000
#define ALT_STDERR_DEV uart_0
#define ALT_STDERR_IS_UART
#define ALT_STDERR_PRESENT
#define ALT_STDERR_TYPE "altera_avalon_uart"
#define ALT_STDIN "/dev/uart_0"
#define ALT_STDIN_BASE 0x8000a000
#define ALT_STDIN_DEV uart_0
#define ALT_STDIN_IS_UART
#define ALT_STDIN_PRESENT
#define ALT_STDIN_TYPE "altera_avalon_uart"
#define ALT_STDOUT "/dev/uart_0"
#define ALT_STDOUT_BASE 0x8000a000
#define ALT_STDOUT_DEV uart_0
#define ALT_STDOUT_IS_UART
#define ALT_STDOUT_PRESENT
#define ALT_STDOUT_TYPE "altera_avalon_uart"
#define ALT_SYSTEM_NAME "RL_system"


/*
 * direct_window_bridge_0_cntl configuration
 *
 */

#define ALT_MODULE_CLASS_direct_window_bridge_0_cntl direct_window_bridge
#define DIRECT_WINDOW_BRIDGE_0_CNTL_BASE 0x8000a060
#define DIRECT_WINDOW_BRIDGE_0_CNTL_BURSTCOUNT_WIDTH 1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_BYTEENABLE_WIDTH 8
#define DIRECT_WINDOW_BRIDGE_0_CNTL_CNTL_ADDRESS_WIDTH 1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_DATA_WIDTH 64
#define DIRECT_WINDOW_BRIDGE_0_CNTL_IRQ -1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_MASTER_ADDRESS_WIDTH 0x20
#define DIRECT_WINDOW_BRIDGE_0_CNTL_MAX_BURST_BYTES 8
#define DIRECT_WINDOW_BRIDGE_0_CNTL_MAX_BURST_WORDS 1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_NAME "/dev/direct_window_bridge_0_cntl"
#define DIRECT_WINDOW_BRIDGE_0_CNTL_SLAVE_ADDRESS_SHIFT 0x3
#define DIRECT_WINDOW_BRIDGE_0_CNTL_SLAVE_ADDRESS_WIDTH 0x1b
#define DIRECT_WINDOW_BRIDGE_0_CNTL_SPAN 8
#define DIRECT_WINDOW_BRIDGE_0_CNTL_SUB_WINDOW_COUNT 1
#define DIRECT_WINDOW_BRIDGE_0_CNTL_TYPE "direct_window_bridge"


/*
 * direct_window_bridge_0_s0 configuration
 *
 */

#define ALT_MODULE_CLASS_direct_window_bridge_0_s0 direct_window_bridge
#define DIRECT_WINDOW_BRIDGE_0_S0_BASE 0x40000000
#define DIRECT_WINDOW_BRIDGE_0_S0_BURSTCOUNT_WIDTH 1
#define DIRECT_WINDOW_BRIDGE_0_S0_BYTEENABLE_WIDTH 8
#define DIRECT_WINDOW_BRIDGE_0_S0_CNTL_ADDRESS_WIDTH 1
#define DIRECT_WINDOW_BRIDGE_0_S0_DATA_WIDTH 64
#define DIRECT_WINDOW_BRIDGE_0_S0_IRQ -1
#define DIRECT_WINDOW_BRIDGE_0_S0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DIRECT_WINDOW_BRIDGE_0_S0_MASTER_ADDRESS_WIDTH 0x20
#define DIRECT_WINDOW_BRIDGE_0_S0_MAX_BURST_BYTES 8
#define DIRECT_WINDOW_BRIDGE_0_S0_MAX_BURST_WORDS 1
#define DIRECT_WINDOW_BRIDGE_0_S0_NAME "/dev/direct_window_bridge_0_s0"
#define DIRECT_WINDOW_BRIDGE_0_S0_SLAVE_ADDRESS_SHIFT 0x3
#define DIRECT_WINDOW_BRIDGE_0_S0_SLAVE_ADDRESS_WIDTH 0x1b
#define DIRECT_WINDOW_BRIDGE_0_S0_SPAN 1073741824
#define DIRECT_WINDOW_BRIDGE_0_S0_SUB_WINDOW_COUNT 1
#define DIRECT_WINDOW_BRIDGE_0_S0_TYPE "direct_window_bridge"


/*
 * epcs_flash_controller_0 configuration
 *
 */

#define ALT_MODULE_CLASS_epcs_flash_controller_0 altera_avalon_epcs_flash_controller
#define EPCS_FLASH_CONTROLLER_0_BASE 0x80009000
#define EPCS_FLASH_CONTROLLER_0_IRQ 2
#define EPCS_FLASH_CONTROLLER_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define EPCS_FLASH_CONTROLLER_0_NAME "/dev/epcs_flash_controller_0"
#define EPCS_FLASH_CONTROLLER_0_REGISTER_OFFSET 1024
#define EPCS_FLASH_CONTROLLER_0_SPAN 2048
#define EPCS_FLASH_CONTROLLER_0_TYPE "altera_avalon_epcs_flash_controller"


/*
 * hal configuration
 *
 */

#define ALT_INCLUDE_INSTRUCTION_RELATED_EXCEPTION_API
#define ALT_MAX_FD 32
#define ALT_SYS_CLK TIMER_0
#define ALT_TIMESTAMP_CLK none


/*
 * hps_0_bridges configuration as viewed by direct_window_bridge_0
 *
 */

#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_BASE 0x0
#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_IRQ -1
#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_IRQ_INTERRUPT_CONTROLLER_ID -1
#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_NAME "/dev/hps_0_bridges"
#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_SPAN 4294967296
#define DIRECT_WINDOW_BRIDGE_0_HPS_0_BRIDGES_TYPE "hps_bridge_avalon"


/*
 * onchip_memory configuration
 *
 */

#define ALT_MODULE_CLASS_onchip_memory altera_avalon_onchip_memory2
#define ONCHIP_MEMORY_ALLOW_IN_SYSTEM_MEMORY_CONTENT_EDITOR 0
#define ONCHIP_MEMORY_ALLOW_MRAM_SIM_CONTENTS_ONLY_FILE 0
#define ONCHIP_MEMORY_BASE 0x90040000
#define ONCHIP_MEMORY_CONTENTS_INFO ""
#define ONCHIP_MEMORY_DUAL_PORT 0
#define ONCHIP_MEMORY_GUI_RAM_BLOCK_TYPE "AUTO"
#define ONCHIP_MEMORY_INIT_CONTENTS_FILE "RL_system_onchip_memory"
#define ONCHIP_MEMORY_INIT_MEM_CONTENT 1
#define ONCHIP_MEMORY_INSTANCE_ID "NONE"
#define ONCHIP_MEMORY_IRQ -1
#define ONCHIP_MEMORY_IRQ_INTERRUPT_CONTROLLER_ID -1
#define ONCHIP_MEMORY_NAME "/dev/onchip_memory"
#define ONCHIP_MEMORY_NON_DEFAULT_INIT_FILE_ENABLED 0
#define ONCHIP_MEMORY_RAM_BLOCK_TYPE "AUTO"
#define ONCHIP_MEMORY_READ_DURING_WRITE_MODE "DONT_CARE"
#define ONCHIP_MEMORY_SINGLE_CLOCK_OP 0
#define ONCHIP_MEMORY_SIZE_MULTIPLE 1
#define ONCHIP_MEMORY_SIZE_VALUE 220000
#define ONCHIP_MEMORY_SPAN 220000
#define ONCHIP_MEMORY_TYPE "altera_avalon_onchip_memory2"
#define ONCHIP_MEMORY_WRITABLE 1


/*
 * pio_0 configuration
 *
 */

#define ALT_MODULE_CLASS_pio_0 altera_avalon_pio
#define PIO_0_BASE 0x8000a050
#define PIO_0_BIT_CLEARING_EDGE_REGISTER 0
#define PIO_0_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PIO_0_CAPTURE 0
#define PIO_0_DATA_WIDTH 16
#define PIO_0_DO_TEST_BENCH_WIRING 0
#define PIO_0_DRIVEN_SIM_VALUE 0
#define PIO_0_EDGE_TYPE "NONE"
#define PIO_0_FREQ 98412698
#define PIO_0_HAS_IN 1
#define PIO_0_HAS_OUT 1
#define PIO_0_HAS_TRI 0
#define PIO_0_IRQ -1
#define PIO_0_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PIO_0_IRQ_TYPE "NONE"
#define PIO_0_NAME "/dev/pio_0"
#define PIO_0_RESET_VALUE 0
#define PIO_0_SPAN 16
#define PIO_0_TYPE "altera_avalon_pio"


/*
 * pio_1 configuration
 *
 */

#define ALT_MODULE_CLASS_pio_1 altera_avalon_pio
#define PIO_1_BASE 0x8000a040
#define PIO_1_BIT_CLEARING_EDGE_REGISTER 0
#define PIO_1_BIT_MODIFYING_OUTPUT_REGISTER 0
#define PIO_1_CAPTURE 0
#define PIO_1_DATA_WIDTH 20
#define PIO_1_DO_TEST_BENCH_WIRING 0
#define PIO_1_DRIVEN_SIM_VALUE 0
#define PIO_1_EDGE_TYPE "NONE"
#define PIO_1_FREQ 98412698
#define PIO_1_HAS_IN 1
#define PIO_1_HAS_OUT 1
#define PIO_1_HAS_TRI 0
#define PIO_1_IRQ -1
#define PIO_1_IRQ_INTERRUPT_CONTROLLER_ID -1
#define PIO_1_IRQ_TYPE "NONE"
#define PIO_1_NAME "/dev/pio_1"
#define PIO_1_RESET_VALUE 0
#define PIO_1_SPAN 16
#define PIO_1_TYPE "altera_avalon_pio"


/*
 * timer_0 configuration
 *
 */

#define ALT_MODULE_CLASS_timer_0 altera_avalon_timer
#define TIMER_0_ALWAYS_RUN 0
#define TIMER_0_BASE 0x8000a020
#define TIMER_0_COUNTER_SIZE 32
#define TIMER_0_FIXED_PERIOD 0
#define TIMER_0_FREQ 98412698
#define TIMER_0_IRQ 0
#define TIMER_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define TIMER_0_LOAD_VALUE 98412
#define TIMER_0_MULT 0.001
#define TIMER_0_NAME "/dev/timer_0"
#define TIMER_0_PERIOD 1
#define TIMER_0_PERIOD_UNITS "ms"
#define TIMER_0_RESET_OUTPUT 0
#define TIMER_0_SNAPSHOT 1
#define TIMER_0_SPAN 32
#define TIMER_0_TICKS_PER_SEC 1000
#define TIMER_0_TIMEOUT_PULSE_OUTPUT 0
#define TIMER_0_TYPE "altera_avalon_timer"


/*
 * uart_0 configuration
 *
 */

#define ALT_MODULE_CLASS_uart_0 altera_avalon_uart
#define UART_0_BASE 0x8000a000
#define UART_0_BAUD 19200
#define UART_0_DATA_BITS 8
#define UART_0_FIXED_BAUD 1
#define UART_0_FREQ 98412698
#define UART_0_IRQ 1
#define UART_0_IRQ_INTERRUPT_CONTROLLER_ID 0
#define UART_0_NAME "/dev/uart_0"
#define UART_0_PARITY 'N'
#define UART_0_SIM_CHAR_STREAM ""
#define UART_0_SIM_TRUE_BAUD 0
#define UART_0_SPAN 32
#define UART_0_STOP_BITS 1
#define UART_0_SYNC_REG_DEPTH 2
#define UART_0_TYPE "altera_avalon_uart"
#define UART_0_USE_CTS_RTS 0
#define UART_0_USE_EOP_REGISTER 0

#endif /* __SYSTEM_H_ */
