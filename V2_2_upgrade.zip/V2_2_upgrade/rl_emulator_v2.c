/*
              *****************************************************************************
              *  Copyright (C) by Reinhard Heuberger                                 *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************
                                        RL02 Emulator
                                        Version V.2.2

                     by: Reinhard Heuberger , www.PDP11GY.com, info@pdp11gy.com


                                 Data - Structure and Mapping:

                         |<---- 8 MB onboard SD RAM ----->|      |<- DP-RAM-->|

              / 5.898240 +-------------+
             /           |Cylinder #511|
   +--------+   5.886720 +-------------+
   |        |            |             |
   |   SD   |            .             .
   |  CARD  |            .             .  /---+------------+    /+------------+
   |        |            |             | /    |  Track #1  |   / |  1 Track   |
   +--------+     11520  +-------------+/     |- - - - - - |--/  | 5760 words |
             \           | Cylinder #0 |      |  Track #0  |     |   DP-RAM   |
              \    0000  +-------------+ - - -+------------+- - -+------------+

        The DEC RL01/RL02 disk drive did have a capacity of 5.2MB/10.4MB
                 2 Heads(surfaces), 256/512 cylinder , 40 sectors/track.
                1 sector contains 128 16-bit words ( 256 Byte ) of Data
        + 12 16-Bit words for Servo/Header/CRC Data = 140 words(280 Byte)/sector.


  SD-Card support is based on the SPI interface from: http://www.emb4fun.de/fpga/fatfs/index.html
     with full FAT32 support using ChaN's FatFs ( http://elm-chan.org/fsw/ff/00index_e.html ).

  History: Version V.3.00 : Migration to Quartus II +  NIOS II Embedded Design SuiteVersion 11.1
           Version V.3.01 : Migration from Altera SOPC to  Altera QSYS
           Version V.3.02 : Add SPI interface to get full FAT32 support for SD-Card via ChaN's FatFs
           Version V.3.03 : Firmware changes/bug fixes ( simultaneously copy/device) + improvements
           Version V.3.04 : Speed improvement. DPR is now included in QSYS. Result: A memcpy is
                            replacing the previously used PIO based controlled I/O. Offline mode will
                            now construct Cylinder 0+1 and the bad sector file in memory.
           Version V.4.0A : Redesign based on BeMicro CV board running with Quartus V14.0
           Version V.4.0B : ########### Support for 4 RL Units simultaneously ############
           Version V.4.0C : Upgrade to Version Quartus 15.1 and Bug fixes concerning simultaneously
                            multiple Units support. Tested DEZ-15 to SEP-16
                            Prepared to use WLAN (Switch 8)                    but  NOT implemented
                            Prepared to use Directory Select Mode  ( Switch 6) but  NOT implemented
           ################################### Update -Info, SEP-16 ###################################
                                  The BeMicro CV board is no longer available
                                  ###########################################

          Version V5.00 :  Same code, but with other PIN-layout using the general RL Interface,
                           connected to J4 @ BeMicro ( JAN 2017 ) @Version Quartus V15.1
                MAR 2017 : Ported to Quartus Version V16.1 using the CMM pinout
--------------------------------------------------------------------------------------------------------------------
          APR 2017: Software ported to DE10-Lite board which is based on a MAX10
          ----------------------------------------------------------------------
          ----------------------------------------------------------------------
          Version 1.1: changes in file  RL_emulator.qpf concerin pull-up @ SW0 - SW7 // 27-JUN-17
          Version 1.2: Speed improvment
          Version 1.3: Skipped
          Version 1.4: Select mode implemented via onboard switches 3 to 6           // 06-AUG-17
          	           Prepared to use WLAN via uart_1
          	           All Verilog's and schematics optimized and Qsys improved
          Version 1.5: Bug fix + Doku, final version also by: https://github.com/pdp11gy/DEC-RL02-RL01-disk-emulator
          Version 2.0: >> Options implemented , like cartridge Serial-Nr. handling and the possibility to
                       include own comments per Subset. Firmware, MFM Decoder finished with one schematics.
                       WLAN basics implemented, such as debug-messages via WIFI. NO more investment !

                      ****************************************************************************************
                       Dieses Projekt wird von mir nicht mehr weiterentwickelt! Notfalls noch Bug-fixe Es ist
                       mehr als ent�uschend wie schlecht, bzw. wie gar nicht eine Zusammenarbeit klappt. Mit
                       USA geht ja schon gar nichts ....da gibt es nur bla bla bla und nichts dahinter .....
                       Jeder kocht seine eigene Suppe und will sich mit aller Gewalt profilieren. Ich hoffte
                       immer, es geht um den Erhalt alter Systeme und vor allem um den Erhalt der Software.
                       Vieles w�re noch zus�tzich beim DE10-Lite board m�glich, wie z.B. einen RX02 und einen
                       TU58 emulator. Gibt es schon aber da w�re eben Zusammenarbeit gefragt. Andererseits ist
                       der Aufwand rel. gering im Gegensatz zu diesen RL Emulator. Ich werde hier nichts mehr
                       machen, mir sind auch andere Dinge im Leben wichtiger geworden. Vielleicht portiere ich
                       noch dieses Projekt auf das DE0-Nano-SOC board. Die firmware l�uft ja schon ........
                                                 21-MAI-2018, Pfingstmontag
                      *****************************************************************************************

             V 2.2 :  Bug fix. A write operation is erroneous with the result of an incorrect bit shift
                      offset by 1. The origin of the error was in the schematics firmware module
                      My_MFM_DEcoder_DE10.bdf. The problem was temporary fixed with the C routine
                      READ_drive_from_FPGA but not in the case of being written several times in
                      succession on the same sector. Also, This is the last remaining schematics module
		      and may be replaced by a verilog module in the next release.
                      Every known problem is fixed in version 2.2 , 05-NOV-2018


*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <system.h>
#include <sys/alt_alarm.h>
#include <io.h>
#include "fatfs.h"
#include "diskio.h"
#include "ff.h"
#include "altera_avalon_pio_regs.h"
#include "altera_avalon_uart_regs.h"
//
void delay(unsigned short wait);
void PRESET_one_SECTOR(void);
void startup_leds(void);
void delay(unsigned short wait);
void longdelay(int wait);
void print_binary_16bit_LSB( unsigned short ibit16);
void PRESET_one_SECTOR(void);
void make_header_CRC(void);
void make_data_CRC(void);
void make_bad_sector_file(void);
void SN_default(void);
void SN_write(void);
void SN_read(void);
void SN_rebuild_CRC(void);
void make_offline_track0(void);
void make_rl_structure_in_ram(void);
void make_bootsector(void);
void WRITE_drive_to_FPGA(int point_to_track);
void READ_drive_from_FPGA(int point_to_track);
void get_header_infos(void);
void send_drive_info( unsigned short infodrive);
void acknowledge(void);
void check_SD_Card(void);
void make_FAT32_on_SD_Card(void);
void make_myfile_on_SD_Card(void);
void check_ID(void);
void make_infofile_on_SD_Card(void);
void read_infofile_from_SD_Card(void);
void WRITE_to_SD_Card(void);
void READ_from_SD_Card(void);
void RAM_align(void);
void readwlan(void);
void esp8266output(void);
void print_sector(void);
void print_RAM(void);
//
//
#define DPRAM_BASE 0x10000000                     // !!!!!!! Base-Address Dual-Ported-Ram !!!!!!!!!
#define DPRAM DPRAM_BASE
//
//#########################################################################################################
//                                            SD-CARD & FAT32
static FATFS Fatfs;
static alt_alarm alarm;
static unsigned long Systick = 0;
static volatile unsigned short Timer;   // 1000Hz increment timer

static alt_u32 TimerFunction (void *context)
{
   static unsigned short wTimer10ms = 0;

   (void)context;

   Systick++;
   wTimer10ms++;
   Timer++;

   if (wTimer10ms == 10)
   {
      wTimer10ms = 0;
      ffs_DiskIOTimerproc();  // Drive timer procedure of low level disk I/O module
   }

   return(1);
}

static void IoInit(void)
{
   // Init diskio interface
   ffs_DiskIOInit();
   // Init timer system
   alt_alarm_start(&alarm, 1, &TimerFunction, NULL);
}
//###################################################################################################
//
// Bit 9 = volume check , Bit 7 = Drive Type , Bit 6 = in action current head
#define RL01_OK 0x021D           // Octal:001035 = Drive Status, RL01 is ready/head_0
#define RL02_OK 0x029D           // Octal:001235 = Drive Status, RL02 is ready/head_0
//
#define CYL_size 11520           // One track size,       16Bit words
#define DPR_size 5760            // Dual-Portet-RAM size, 16Bit words
#define RL01_size 255            // RL01 = 256 cylinder ( 0 - 255 )
#define RL02_size 511            // RL02 = 512 cylinder ( 0 - 511 )
#define SEC_size_c 288           // byte:    Sector size, including header/crc/servo  8Bit
#define SEC_size_i 144           // integer: Sector size, including header/crc/servo 16Bit
#define SEC_size_l 72            // long:    Sector size, including header/crc/servo 32Bit
#define TRUE  1
#define FALSE 0
//
// 4 Unit-Size + Base-addresses 16bit in RAM for the RL-Units
#define RAMi 12000000             // Used RAM-Size integer
#define RAMs 24000000             // Used RAM-Size short integer
#define RAMb 48000000             // Used RAM-Size byte
#define RL0_base 0		          // Byte: 0
#define RL1_base 6000000          // Byte: 12000000
#define RL2_base 12000000         // Byte: 18000000
#define RL3_base 18000000         // Byte: 36000000
//
#define RL0SN_1 0x0AF3            //0x2803
#define RL0SN_2 0x07A2            //0x1954
#define RL1SN_1 0x08FE            //0x2302
#define RL1SN_2 0x0781            //0x1921
#define RL2SN_1 0x08A2            //0x2210
#define RL2SN_2 0x077D            //0x1917
#define RL3SN_1 0x07D4            //0x2004
#define RL3SN_2 0x07A4            //0x1956
//
/*        *********************** Global Definitions **********************        */
//
union rld {                                       // ****** one RL01/2 sector *************
       unsigned char  rl02c[512];                 // Access to one Sector via 296 bytes or
       unsigned short rl02i[256];                 // 144 16Bit words  , alligned to 512/256
       unsigned int   rl02l[128];
};
//union  rld SECTOR;                              // define a union of type SECTOR
union  rld SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rld *u_rl02ptr;                            // pointer to union.
//
//
union rlt {
       unsigned char  rl_drive_c[RAMb];           // ***** RL02 Structure @ SD-RAM/=union ********
       unsigned short rl_drive_i[RAMs];           // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rl_drive_l[RAMi];           // 2* 40 sectors = 11520 16 bit * 512 = 5898240/unit
};
//union  rlt RLDRIVE;                             // define a union of type RLDRIVE
union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
union  rlt *u_rl02_drive_ptr;                     // pointer to union
//
unsigned short int header_index =    3;           // Header index =3
unsigned short int data_start =     10;           // + 7, = +header=3 +PD1=1 +PR2=3
unsigned short int data_CRC =      138;           // + 135
unsigned short int RL_unit  =        0;           // configured  RL unit(s) ( Statisch )
unsigned short int RL_Nr    =        0;           // current used Drive Number
unsigned short int RL_Nr_old    =    0;           // Used Drive Number before
unsigned short int RL_match =        0;           // Match for RL Unit binary notation
unsigned short int RL_match_old =    0;           // Used Match before
int SDRAM                   = 11796480;           // Used bytes in RAM for one RL-unit
unsigned short MAXCYL       =      511;           // cylinder, RL01/Rl02
//
short int mode=0;                                 // System operating mode
unsigned char DEBUG=0;                            // DEBUG PURPOSE
unsigned char OFFLINE=0;                          // online/offline mode
unsigned char OFFMODE=0;                          // full/simple offline mode
unsigned char RL=1;                               // 0=RL01 , 1=RL02
unsigned char dl0=0;                              // Unit 0
unsigned char dl1=0;                              // Unit 1
unsigned char dl2=0;                              // Unit 2
unsigned char dl3=0;                              // Unit 3
//
unsigned char RL_drive_nr_changed=0;              // Flag to indicate a RL-drive UNIT number change was done
//
unsigned char selmode=0;                          // switch 6, select mode active
unsigned char WIFI=0;                             // WLAN, defaut = OFF(FALSE)
unsigned char usingdefault=0;
//
unsigned short int head=0, Old_head=0;
unsigned short int dl0_head=0, dl0_Old_head=0;
unsigned short int dl1_head=0, dl1_Old_head=0;
unsigned short int dl2_head=0, dl2_Old_head=0;
unsigned short int dl3_head=0, dl3_Old_head=0;
//
int Cylinder_nr=0;                               // Cylinder number , 0 - 255 ( RL02 )
int dl0_cnr=0, dl1_cnr=0, dl2_cnr=0, dl3_cnr=0;
//
int Old_Cyl_nr = 0;                                // Cylinder address SAVE
int dl0_Old_Cyl_nr=0, dl1_Old_Cyl_nr=0, dl2_Old_Cyl_nr=0, dl3_Old_Cyl_nr=0;
//
int Cylinder_nr_diff = 0;                       // Difference to last cylinder_adress
int RAM_cyl_addr;                               // Address @RAM , (Cylinder_nr * CYL_size)
//
int BASE = RL0_base;
int DEST = RL1_base;
int rlBASE;
int RAM_Address = RL0_base;
int Old_RAM_Address = RL0_base;
//
unsigned int rlname;
char *myfile1 = "PDP11GY.INF";
char *myfile2 = "RL01_0.DEC";
//
char *myfile3 = "SN.TXT";
char *myfile4 = "RL.TXT";
//
FILE* fp;
char c;
/*************************************************************************************/
//
//
void startup_leds(void)
{
short  is;
short  count = 4;
int laufled = 0x00000001;
    for (count = 0; count < 4; count++ )  {
      IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);
        for (is = 0; is < 16; is++ )  {
          IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, laufled);
            // IOPIN1 = laufled<<16;
            delay(4000);                   // wait
            laufled = laufled <<1;
        }
        IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x8000);   //$$
        for (is = 0; is < 16; is++ )  {
            //IOPIN1 = laufled<<16;
            IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, laufled);
            delay(4000);                // wait
            laufled = laufled >>1;
       }
       IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0000);
    }
}
//
void delay( unsigned short wait)
//   Based on Nios II/e core CPU running at 50MHz
// Value wait; 1000=6.6ms  , 500=3.2ms  , 100=0.66ms
{
     while (wait) {
           wait = wait -1;
     }
}
void longdelay( int wait)
{
     while (wait) {
           wait = wait -1;
     }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void PRESET_one_SECTOR(void) {
  // initialize data for one sector used for test and reference purpose.
  int i;
  header_index = 3;                                                   // **** Set ****
  data_start = header_index + 7;                                      // **** Set ****
  data_CRC = header_index + 135;                                      // **** Set ****
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x8000,                                           //  PR1,header_index=3
    0x0000, 0x0000, 0x0000,                                           //  Header
    0x0000,                                                           //  PD1
    0x0000, 0x0000, 0x8000,                                           //  PR2
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x4C52, 0x3230, 0x532D, 0x4D49, 0x4C55,   //  Data 66-73
    0x5441, 0x524F, 0x5620, 0x4E4F, 0x5220, 0x4945, 0x484E, 0x5241,   //  Data 74-81
    0x2044, 0x4548, 0x4255, 0x5245, 0x4547, 0x0A52, 0x520D, 0x304C,   //  Data 82-89
    0x2D32, 0x4953, 0x554D, 0x414C, 0x4F54, 0x2052, 0x4F56, 0x204E,   //  Data 90-97
    0x4552, 0x4E49, 0x4148, 0x4452, 0x4820, 0x5545, 0x4542, 0x4752,   //  Data 98-105
    0x5245, 0x0D0A, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 106-113
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x3A33,                                                           //  Data 128 = CRC
    0x0000,                                                           //  129 = PD2
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 }; //  146-153=Zero
  //
  //
  for (i = 0; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }             // clear buffer
  for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }        // Load buffer
  //make_data_CRC();
    SECTOR.rl02l[100]=0x2E575757; // "WWW."
    SECTOR.rl02l[101]=0x31504450; // "PDP1"
    SECTOR.rl02l[102]=0x2E594731; // "1GY."
    SECTOR.rl02l[103]=0x204D4F43; // "COM "
    SECTOR.rl02l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16 = 0;
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2],0xA001);   //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3  ( always 0 )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.rl02i[header_index+2]=DEVICE_CRC16;
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //
  for (i = data_start; i < data_CRC; i++ ){
    MSB = i<<1;      // = i*2
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[LSB],0xA001);
  }
  SECTOR.rl02i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}
//
//
void make_bad_sector_file(void) {
// reconstruct error free RL Cartridge (EF)
   unsigned short int j = data_start, i=0;
   //
   SECTOR.rl02i[j]   = RL0SN_1;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+1] = RL0SN_2;                          // 0,1 = Cartridge SN
   SECTOR.rl02i[j+2] = 0x0000;                           // 2 = unused
   SECTOR.rl02i[j+3] = 0x0000;                           // 3 = Written with Zeros for Data Cartridge
   SECTOR.rl02i[j+4] = 0xFFFF;                           // 4 = Ones until End of sector = Error free
   for (i = j+4; i < 256; i++ ){
      if( i > data_start +128) {
         SECTOR.rl02i[i] = 0x000;
      } else {
          SECTOR.rl02i[i] = 0xFFFF;
      }
   }
   make_data_CRC();
}
//
//
void SN_default(void) {
// set default Cartridge Serial numbers for DL0 to DL1
	int point;
	point = (SEC_size_i*80)*MAXCYL + data_start;
	//
	RLDRIVE.rl_drive_i[point] = RL0SN_1;
	RLDRIVE.rl_drive_i[point+1] = RL0SN_2;
	RLDRIVE.rl_drive_i[point+RL1_base] = RL1SN_1;
    RLDRIVE.rl_drive_i[point+RL1_base+1] = RL1SN_2;
    RLDRIVE.rl_drive_i[point+RL2_base] = RL2SN_1;
    RLDRIVE.rl_drive_i[point+RL2_base+1] = RL2SN_2;
    RLDRIVE.rl_drive_i[point+RL3_base] = RL3SN_1;
    RLDRIVE.rl_drive_i[point+RL3_base+1] = RL3SN_2;
    //
}
//
//
void SN_write(void){
// Write serial-numbers to SD-Card, in file SNx.txt
//
	FRESULT FResult;
    FIL     hFile;
    //
    int point;
    point = (SEC_size_i*80)*MAXCYL + data_start;
	//
    FResult = f_open(&hFile, myfile3, FA_CREATE_ALWAYS | FA_WRITE);
	if (FResult != FR_OK) {
	  printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
	  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
	  while(1); }
	//
	f_printf(&hFile, "%X,%X",RLDRIVE.rl_drive_i[point],RLDRIVE.rl_drive_i[point+1]);
	f_printf(&hFile, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL1_base+point],RLDRIVE.rl_drive_i[RL1_base+point+1]);
	f_printf(&hFile, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL2_base+point],RLDRIVE.rl_drive_i[RL2_base+point+1]);
	f_printf(&hFile, "\r\n%X,%X",RLDRIVE.rl_drive_i[RL3_base+point],RLDRIVE.rl_drive_i[RL3_base+point+1]);
    FResult = f_close(&hFile);
}
//
//
void SN_read(void){
// Read and Set serial-numbers ( HEX ) from SD-CARD, file SNx.txt
// Note !!! DATA CRC has to be rebuild !!!!!
//
	FRESULT FResult;
	FIL     hFile;
	int point;
        point = (SEC_size_i*80)*MAXCYL + data_start;
	char EineZeile[100];
	char * pch;
	//
	if(OFFLINE == FALSE) {
	  FResult = f_open(&hFile, myfile3, FA_READ);
          if (FResult != FR_OK) {
		  //printf ("\n\n\r\x07 ERROR opening SN file: %s , using defaults \n\r", myfile3);
		  printf ("\n\n\r\x07 SN file: %s not available, leave the set values \n\r", myfile3);
		  usingdefault=1;
	  } else {
		  usingdefault=0;
		  //
		  f_gets(EineZeile, sizeof(EineZeile), &hFile);                // read one line
		  //printf ("\r\nDL0: %s", EineZeile);
		  pch = strtok (EineZeile,",");                                // split string
		  //RLDRIVE.rl_drive_i[point] = atoi(pch);                     // mit atoi gehts nicht :-(
		  RLDRIVE.rl_drive_i[point] = strtol(pch, 0, 16);
		  pch = strtok (NULL, ",");                                    // split string
		  RLDRIVE.rl_drive_i[point+1] = strtol(pch, 0, 16);
		  //
		  rlBASE=RL0_base;
		  SN_rebuild_CRC();
                  //
		  f_gets(EineZeile, sizeof(EineZeile), &hFile);                // read one line
		  //printf ("\r\nDL1: %s", EineZeile);
		  pch = strtok (EineZeile,",");                                // split string
		  RLDRIVE.rl_drive_i[RL1_base+point] = strtol(pch, 0, 16);
		  pch = strtok (NULL, ",");                                    // split string
		  RLDRIVE.rl_drive_i[RL1_base+point+1] = strtol(pch, 0, 16);
          //
		  rlBASE=RL1_base;
		  SN_rebuild_CRC();
		  //
		  f_gets(EineZeile, sizeof(EineZeile), &hFile);                // read one line
		  //printf ("\r\nDL2: %s", EineZeile);
		  pch = strtok (EineZeile,",");                                // split string
		  RLDRIVE.rl_drive_i[RL2_base+point] = strtol(pch, 0, 16);
		  pch = strtok (NULL, ",");                                    // split string
		  RLDRIVE.rl_drive_i[RL2_base+point+1] = strtol(pch, 0, 16);
          //
		  rlBASE=RL2_base;
		  SN_rebuild_CRC();
          //
		  f_gets(EineZeile, sizeof(EineZeile), &hFile);                // read one line
		  //printf ("\r\nDL3: %s", EineZeile);
		  pch = strtok (EineZeile,",");                                // split string
		  RLDRIVE.rl_drive_i[RL3_base+point] = strtol(pch, 0, 16);
		  pch = strtok (NULL, ",");                                    // split string
		  RLDRIVE.rl_drive_i[RL3_base+point+1] = strtol(pch, 0, 16);
          //
		  rlBASE=RL3_base;
		  SN_rebuild_CRC();
		  //
		  //
	  }
      FResult = f_close(&hFile);
	}
}
//
void SN_rebuild_CRC(void){
  int point, i;
  point = (SEC_size_i*80)*MAXCYL + rlBASE;
  //
  for(i = 0; i< SEC_size_i; i++) {
	SECTOR.rl02i[i] = RLDRIVE.rl_drive_i[point+i];
  }
  make_data_CRC();
  //
  for(i = 0; i< SEC_size_i; i++) {
    RLDRIVE.rl_drive_i[point+i] = SECTOR.rl02i[i];
  }
}
//
void SN_print(void){
	int point;
	point = (SEC_size_i*80)*MAXCYL + data_start;
	//
	if(OFFLINE==FALSE){
	  printf("\r\n   RL cartridges Serial-Numbers(HEX)");
	  if(usingdefault==FALSE){printf(", located in file %s", myfile3);}
	  //
	  if(dl0 == FALSE){ printf("\r\n      DL0: not in use"); } else {
	   printf("\r\n      DL0: %X,%X",RLDRIVE.rl_drive_i[point],RLDRIVE.rl_drive_i[point+1]);}
	  if(dl1 == FALSE){ printf("\r\n      DL1: not in use"); } else {
	   printf("\r\n      DL1: %X,%X",RLDRIVE.rl_drive_i[RL1_base+point],RLDRIVE.rl_drive_i[RL1_base+point+1]);}
	  if(dl2 == FALSE){ printf("\r\n      DL2: not in use"); } else {
	   printf("\r\n      DL2: %X,%X",RLDRIVE.rl_drive_i[RL2_base+point],RLDRIVE.rl_drive_i[RL2_base+point+1]);}
	  if(dl3 == FALSE){ printf("\r\n      DL3: not in use"); } else {
	   printf("\r\n      DL3: %X,%X",RLDRIVE.rl_drive_i[RL3_base+point],RLDRIVE.rl_drive_i[RL3_base+point+1]);}
	  printf("\r\n");
	}
}
//
//
void make_offline_track0(void) {
 // construct sector data  @ cylinder 0+1 and bad sector file into memory
 unsigned short int RL_sector,  RL_cylinder=0, i, temp;
 int nr = 0;
 printf ("\n\r              ********* OFFLINE MODE *********");
 printf ("\n\r              *  Construct cylinder 0-31 and *");
 printf ("\n\r              *     bad sector file only     *");
 printf ("\n\r              ********************************\n\r");
  //
  for (RL_cylinder = 0; RL_cylinder < 31; RL_cylinder++ ) {
  //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 0
      temp = 0;
      temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
      temp = temp | RL_sector;                          // Set RL01-Sector
      temp = temp &~0x40;                               // Clear = select head-0
      SECTOR.rl02i[header_index] = temp;                // >> SET <<
      make_header_CRC();                                // build header CRC
      //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
         make_bootsector();}
      for(i = 0; i< SEC_size_i; i++) {
          RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
      }
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
        PRESET_one_SECTOR(); }
      nr = nr + SEC_size_i;
    }
    //
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {     // construct 40 sectors @ head 1
        temp = 0;
      temp = RL_cylinder<<7;                             // Set RL-Cylinder address
      temp = temp | RL_sector;                           // Set RL-Sector
      temp = temp | 0x40;                                // Set = select head-1
      SECTOR.rl02i[header_index] = temp;                 // >> SET <<
      make_header_CRC();                                 // build header CRC
      for(i = 0; i< SEC_size_i; i++) {
         RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
      }
      nr = nr + SEC_size_i;
     }
   }
   //
   make_bad_sector_file();
   RL_cylinder = MAXCYL;
   nr = (SEC_size_i*80)*MAXCYL;                           // point to last,= bad sector Cylinder
   //
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
}
//
//
void make_rl_structure_in_ram(void) {
// +
// construct full RL01/RL02 image in Memory ( union = SD RAM )
// the idea behind this routine is to dump the memory contents in pieces of 512 byte
// to the SD-Card after constructing the RL01 image in Memory.
// -
unsigned short int RL_sector, RL_cylinder, dot=0, led0=0x0001, led1=0x8000, i;
short int temp;
int nr=0;
 //printf("\n\r MAXCYL:   %d \r\n", MAXCYL);
 for (RL_cylinder = 0; RL_cylinder < MAXCYL; RL_cylinder++ ) {
  //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) { // construct 40 sectors @ head 0
      temp = 0;
      temp = RL_cylinder<<7;                            // Set RL-Cylinder address
      temp = temp | RL_sector;                          // Set RL-Sector
      temp = temp &~0x40;                               // Clear = select head-0
      SECTOR.rl02i[header_index] = temp;                // >> SET <<
      make_header_CRC();                                // build header CRC
      //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
         make_bootsector();}
      for(i = 0; i< SEC_size_i; i++) {
          RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
      }
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
        PRESET_one_SECTOR(); }
      nr = nr + SEC_size_i;
    }
    //
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led1);
    if(led1 == 0x0000){ led1=0x8000; } led1=led1>>1;
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
      temp = RL_cylinder<<7;                             // Set RL-Cylinder address
      temp = temp | RL_sector;                           // Set RL-Sector
      temp = temp | 0x40;                                // Set = select head-1
      SECTOR.rl02i[header_index] = temp;                 // >> SET <<
      make_header_CRC();                                 // build header CRC
      for(i = 0; i< SEC_size_i; i++) {
         RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
      }
      nr = nr + SEC_size_i;
     }
     if(dot >56){printf("\r*");dot=0;}else{printf("*");}dot++;
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led0);
     if(led0 == 0x0000){ led0=0x0001; } led0=led0<<1;
   }
   // RT-11 command to get contents of RL01 Bad Sector file: dump/term/only:23730 dl0:
   //
   make_bad_sector_file();
   //
   RL_cylinder = MAXCYL;                                  // point to last cylinder
   //
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
 }
//
//
void make_bootsector(void) {
 short int i;
 unsigned short bootsector[]=
 { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,       // * ..........C....*
   0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,       // *7.$.......?BOOT-*
   0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,       // *U-No boot on vol*
   0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,       // *ume....._.t.}...*
   0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };     // *v.z.............*
  //
  for (i = data_start; i < 256; i++ ) {
	SECTOR.rl02i[i] = 0x0000;                                             // clear data area
  }
  for (i = 0; i < 40; i++){
    SECTOR.rl02i[i+data_start] = bootsector[i];                           // init Sector
  }
  make_data_CRC();
}
//
//
void WRITE_drive_to_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine writes one sector from union RLDRIVE.rl_drive_i to FPGA/DP-RAM
  //                               ##################
  //                               ### RAM-->FPGA ###
  //                               ##################
  //
  //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
  //	printf("\n\r>>> RAM -> FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
  //
  memcpy((void *)(DPRAM), &RLDRIVE.rl_drive_i[point_to_track], SEC_size_c * 40);
  //
}
//
//
void READ_drive_from_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine reads one sector from FPGA/DP-RAM into union RLDRIVE.rl_drive_i
  //                               ##################
  //                               ### FPGA-->RAM ###
  //                               ##################
  //
  //if((DEBUG == TRUE) & (OFFLINE == TRUE)){
  //   printf("\n\r<<< RAM <- FPGA/DPR @Base: %d  = Track-Address: %d \n\r", BASE, point_to_track); }
  //
  memcpy(&RLDRIVE.rl_drive_i[point_to_track], (void *)(DPRAM), SEC_size_c * 40);
  //
  //-----------------------------------------------------------------------+
	// This error handling is no longer necessary.  The cause of the problem
	// was related to the firmware and is fixed with version 2.2.
	int DATAOFFS = data_start*2 , point = point_to_track*2 ,i,k ;
    for(i = 0 ; i < 40; i++) {
		if (RLDRIVE.rl_drive_c[point + DATAOFFS - 1] != 0x80)  {
		    if (RLDRIVE.rl_drive_c[point + DATAOFFS - 1] & 0x40)  {
			    for (k = point+DATAOFFS + 258; k >= point+DATAOFFS - 1; k--) {
                  RLDRIVE.rl_drive_c[k] = (RLDRIVE.rl_drive_c[k] << 1) | (RLDRIVE.rl_drive_c[k - 1] >> 7);
              }
		    }else{
		       printf("\n\r\x07 Non-correctable bit-shift error @PR2: %04X ",RLDRIVE.rl_drive_c[point + DATAOFFS - 1] );
			}
		}
	    point = point + SEC_size_c;
  }
  //-----------------------------------------------------------------------+
  //
}
//
//
void get_header_infos(void) {
  short int i=0, j=0, k=0;
  printf ("\n\r++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
  for (i=0; i < 40; i++ ) {
    printf ("\n\r  ");
  for (k=0; k < 8; k++ ) {
    print_binary_16bit_LSB(RLDRIVE.rl_drive_i[j+k]);
      //LSB_print_binary_16bit(RLDRIVE.rl_drive_i[j+k]);
    printf ("  ");
  }
  j=j+SEC_size_i;
  }
  printf ("\n\r++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
}
//
//
void send_drive_info( unsigned short infodrive){
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, infodrive);                 // Preset PIO
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode|0x0004));      // Set Acknowledge
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode&~0x0004));     // Clear Acknowledge
}
//
//
void check_SD_Card(void){
  DSTATUS DStatus;
  FRESULT FResult;
  //
  DStatus = disk_initialize(0);
  if (DStatus != 0){
    printf ("\n\r\x07 No SD card! Insert SD-Card & restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
  //
  FResult = f_mount(0, &Fatfs);
  if (FResult != FR_OK){
    printf ("\n\r\x07 No valid SD card! Restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
}
//
//
void make_FAT32_on_SD_Card(void){
  FRESULT FResult;
  FResult = f_mkfs(0, 0, 4096);
  if (FResult != FR_OK) {
    printf ("\n\r\x07 ERROR formatting SD-Card volume! Restart system  \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1);
  }else {
    printf(" "); }
}
//
//
void make_myfile_on_SD_Card(void){
  FRESULT FResult;
  FIL     hFile;
  TCHAR   Buffer[128];
  TCHAR   *pString;
  //
  FResult = f_open(&hFile, myfile1, FA_CREATE_ALWAYS | FA_WRITE);
  if (FResult != FR_OK) {
    printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
    f_printf(&hFile,"              MAX10-FPGA based V2.2 RL01/RL02 disk emulator\r\n");
    f_printf(&hFile,"                   developed with Quartus Version 16.1\r\n");
    f_printf(&hFile,"      PCB design in cooperation with www.computermuseum-muenchen.de\r\n");
    f_printf(&hFile,"                  Copyright (C) by Reinhard Heuberger\r\n");
    f_printf(&hFile,"                   www.pdp11gy.com  info@pdp11gy.com\r\n");
   FResult = f_close(&hFile);
   //
   FResult = f_open(&hFile, myfile4, FA_CREATE_ALWAYS | FA_WRITE);
     if (FResult != FR_OK) {
       printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
       IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
       while(1); }
       f_printf(&hFile,"              MAX10-FPGA based V2.2 RL01/RL02 disk emulator\r\n");
       f_printf(&hFile,"                   developed with Quartus Version 16.1\r\n");
       f_printf(&hFile,"                PCB design in cooperation with www.GfhR.de  \r\n");
       f_printf(&hFile,"                 (C) www.pdp11gy.com  info@pdp11gy.com\r\n");
       f_printf(&hFile,"                 Non Select Mode, info-file RL.TXT  \r\n");
       f_printf(&hFile,"           <Edit the file RL.TXT to change the info-message>\r\n");
     FResult = f_close(&hFile);
   //
   FResult = f_open(&hFile, myfile1 , FA_READ);
   if (FResult != FR_OK) {
     printf ("\n\r\x07 ERROR No SD-Card read access! Restart system \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
     while(1); }
   pString = f_gets(&Buffer[0], sizeof(Buffer), &hFile);
   while (pString != NULL){
   printf("%s", pString);
   pString = f_gets(&Buffer[0], sizeof(Buffer), &hFile);}
   FResult = f_close(&hFile);
}
//
void check_ID(void){
	char *checkfile = "PDP11GY.INF";
	FRESULT FResult;
	FIL     hFile;
	FResult = f_open(&hFile, checkfile, FA_READ);
      if (FResult != FR_OK) {
	  	 printf ("\n\r\x07    ID-File %s is not available !.. using defaults\n\r", checkfile);
	  	 usingdefault=1;
	   }else{
		 usingdefault=0;
	  	 read_infofile_from_SD_Card();
	   }
    FResult = f_close(&hFile);
}
//
//
void make_infofile_on_SD_Card(void){
	  FRESULT FResult;
	  FIL     hFile;
	  //
	  FResult = f_open(&hFile, myfile4, FA_CREATE_ALWAYS | FA_WRITE);
	  if (FResult != FR_OK) {
	   printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
	   IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
	   while(1); }
	  f_printf(&hFile,"              Select-Mode: Info file for disk-subset: %c\r\n", myfile4[2]);
	  f_printf(&hFile,"      < If you want, modify the file %s for your own purposes >\r\n",myfile4);
	  FResult = f_close(&hFile);
}
//
void read_infofile_from_SD_Card(void){
	FRESULT FResult;
	FIL     hFile;
	char EineZeile[100];
	FResult = f_open(&hFile, myfile4, FA_READ);
		if (FResult != FR_OK) {
		   printf ("n\r\x07     ERROR opening info-file: %s\n\r",myfile4);
		} else {
		    while ((f_eof(&hFile) == 0)) {
			  f_gets(EineZeile, sizeof(EineZeile), &hFile);  // read EineZeile
			  printf ("%s", EineZeile);
		    }
		}
	FResult = f_close(&hFile);
}
//
//
void WRITE_to_SD_Card(void){
  //
  // RL01: 5,62 MB ( 5.898.752 Bytes)
  // RL02: 11,2 MB (11.796.992 Bytes)
  //
  FRESULT FResult;
  FIL     hFile;
  uint32_t bytesWritten;
  int loops=SDRAM/20480, i=0, j=0, k=0, unit_base;
  unsigned short dot=0, led=0x8000;
  unsigned char conf=0;
  //
  for(k=0; k<4; k++) {
	  switch(k) {
	   case 0:
		 if((dl0 == TRUE) | (selmode == FALSE)){ conf=1; } else { conf=0;}
	     RL_Nr = 0;
	     unit_base=RL0_base;
	   	 myfile2[5] = '0'; break;
	   case 1:
		 if((dl1 == TRUE) | (selmode == FALSE)){ conf=1; } else { conf=0;}
	   	 RL_Nr = 1;
	   	 unit_base=RL1_base;
	   	 myfile2[5] = '1'; break;
	   case 2:
		 if((dl2 == TRUE) | (selmode == FALSE)){ conf=1; } else { conf=0;}
	   	 RL_Nr = 2;
	   	 unit_base=RL2_base;
	   	 myfile2[5] = '2'; break;
	   case 3:
		 if((dl3 == TRUE) | (selmode == FALSE)){ conf=1; } else { conf=0;}
	   	 RL_Nr = 3;
	     unit_base=RL3_base;
	     myfile2[5] = '3'; break;
	   }
	   printf ("\n\r       Unit number: %d  ", RL_Nr);
	   if(conf == TRUE){
	   	 printf (">  Write to file %s \n\r", myfile2);
         FResult = f_open(&hFile, myfile2, FA_CREATE_ALWAYS | FA_WRITE);
         if (FResult != FR_OK) {
           printf ("\n\r\x07 ERROR opening RL image-file! Restart system \n\r");
           IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
           while(1);
         }
         i=unit_base *2;                                                              // !!! *2, da byte
         for(j=0; j<loops; j++) {
             FResult = f_write(&hFile, (void*)&RLDRIVE.rl_drive_c[i], 20480, &bytesWritten );
             if (FResult != FR_OK) {
               printf ("\n\r\x07 ERROR writing to RL image-file! Restart system \n\r");
               IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                        //$$
               while(1);}
             if(dot >56){printf("\r#");dot=0;}else{printf("#");}dot++;
               IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led);
               if(led == 0x0000){ led=0x8000; } led=led>>1;
               i=i+20480;
        }
        FResult = f_write(&hFile, (void*)&SECTOR.rl02c[0], 512, &bytesWritten  );
       //
       FResult = f_close(&hFile);
       myfile2[5] = '0';
    } else {
      printf (" not configured, will be skipped! \n\r");
    }
  }
}
//
//
void READ_from_SD_Card(void){
  //
  // RL01: 5,62 MB ( 5.898.752 Bytes)
  // RL02: 11,2 MB (11.796.992 Bytes)
  //
  FRESULT FResult;
  FIL     hFile;
  uint32_t bytesWritten;
  int loops=SDRAM/20480, i=0, j=0, k=0, unit_base;
  unsigned short int dot=0, led=0x0001;
  unsigned char conf=0;
  //
  for(k=0; k<4; k++) {
	  switch(k) {
	   case 0:
		 if(dl0 == TRUE){ conf=1; }else{ conf=0;}
	     RL_Nr = 0;
	     unit_base=RL0_base;
	   	 myfile2[5] = '0'; break;
	   case 1:
		 if(dl1 == TRUE){ conf=1; }else{ conf=0;}
	   	 RL_Nr = 1;
	   	 unit_base=RL1_base;
	   	 myfile2[5] = '1'; break;
	   case 2:
		 if(dl2 == TRUE){ conf=1; }else{ conf=0;}
		 RL_Nr = 2;
	   	 unit_base=RL2_base;
	   	 myfile2[5] = '2'; break;
	   case 3:
		 if(dl3 == TRUE){ conf=1; }else{ conf=0;}
	   	 RL_Nr = 3;
	     unit_base=RL3_base;
	     myfile2[5] = '3'; break;
	   }
   printf ("\n\r       Unit number: %d  ", RL_Nr);
   if(conf == TRUE){
	   printf (">  read from file %s \n\r", myfile2);
       FResult = f_open(&hFile, myfile2, FA_READ);
       if (FResult != FR_OK) {
         printf ("\n\r\x07 ERROR opening RL image-file! Restart system \n\r");
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
         while(1);
       }
       i=unit_base *2;                                                             // !!! *2, da byte
       for(j=0; j<loops; j++) {
       FResult = f_read(&hFile, (void*)&RLDRIVE.rl_drive_c[i], 20480, &bytesWritten  );
         if (FResult != FR_OK) {
           printf ("\n\r\x07 ERROR reading from RL image-file! Restart system \n\r");
           IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                        //$$
           while(1);}
         if(dot >56){printf("\r.");dot=0;}else{printf(".");}dot++;
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led);
         if(led == 0x0000){ led=0x0001; } led=led<<1;
         i=i+20480;
       }
       FResult = f_read(&hFile, (void*)&SECTOR.rl02c[0], 512, &bytesWritten );
       //
       FResult = f_close(&hFile);
  }else{
	 if(dl0 == TRUE){
	     printf (" file %s not found: copy DL0 area  \n\r",myfile2 );
	     memcpy(&RLDRIVE.rl_drive_i[unit_base], &RLDRIVE.rl_drive_i[RL0_base], SDRAM );
	 }else{
	     printf (" not configured, will be skipped! \n\r");
	 }
  }
 }
}
//
//
void RAM_align(void) {
    switch(RL_Nr_old){
      //--------------------------------------------------------------
      case 0: {                                       // from Unit 0
        dl0_head = head;                              //
        dl0_Old_head = Old_head;                      ///
        dl0_cnr = Cylinder_nr=0;                      ////
        dl0_Old_Cyl_nr = Old_Cyl_nr;                  ///// save dl0
        switch(RL_Nr){                                // ***
          case 1:                                     //  to Unit 1
              head = dl1_head;
              Old_head = dl1_Old_head;
              Cylinder_nr = dl1_cnr;
              Old_Cyl_nr = dl1_Old_Cyl_nr;
              BASE = RL1_base;break;
          case 2:                                     //  to Unit 2
              head = dl2_head;
              Old_head = dl2_Old_head;
              Cylinder_nr = dl2_cnr;
              Old_Cyl_nr = dl2_Old_Cyl_nr;
              BASE = RL2_base;break;
          case 3:                                     //  to Unit 3
              head = dl1_head;
              Old_head = dl1_Old_head;
              Cylinder_nr = dl3_cnr;
              Old_Cyl_nr = dl1_Old_Cyl_nr;
              BASE = RL3_base;break;
          }
        }break;
       //---------------------------------------------------------
       case 1: {                                    // from unit 1
        dl1_head = head;                            //
        dl1_Old_head = Old_head;                    ///
        dl1_cnr = Cylinder_nr;                      ////
        dl1_Old_Cyl_nr = Old_Cyl_nr;                ///// save dl1
        switch(RL_Nr) {                             // ***
        case 0:                                     //  to Unit 0
            head = dl0_head;
            Old_head = dl0_Old_head;
            Cylinder_nr = dl0_cnr;
            Old_Cyl_nr = dl0_Old_Cyl_nr;
            BASE = RL0_base;break;
        case 2:                                     //  to Unit 2
            head = dl2_head;
            Old_head = dl2_Old_head;
            Cylinder_nr = dl2_cnr;
            Old_Cyl_nr = dl2_Old_Cyl_nr;
            BASE = RL2_base;break;
        case 3:                                     //  to Unit 3
            head = dl1_head;
            Old_head = dl1_Old_head;
            Cylinder_nr = dl3_cnr;
            Old_Cyl_nr = dl1_Old_Cyl_nr;
            BASE = RL3_base;break;
        }
      }break;
     //---------------------------------------------------------
     case 2: {                                      // from unit 2
      dl2_head = head;                              //
      dl2_Old_head = Old_head;                      ///
      dl2_cnr = Cylinder_nr;                        ////
      dl2_Old_Cyl_nr = Old_Cyl_nr;                  ///// save dl1
      switch(RL_Nr) {
        case 0:                                     //  to Unit 0
            head = dl0_head;
            Old_head = dl0_Old_head;
            Cylinder_nr = dl0_cnr;
            Old_Cyl_nr = dl0_Old_Cyl_nr;
            BASE = RL0_base;break;
        case 1:                                     //  to Unit 1
            head = dl1_head;
            Old_head = dl1_Old_head;
            Cylinder_nr = dl1_cnr;
            Old_Cyl_nr = dl1_Old_Cyl_nr;
            BASE = RL1_base;break;
        case 3:                                     //  to Unit 3
            head = dl3_head;
            Old_head = dl3_Old_head;
            Cylinder_nr = dl3_cnr;
            Old_Cyl_nr = dl3_Old_Cyl_nr;
            BASE = RL3_base;break;
       }
     }break;
    //---------------------------------------------------------
    case 3: {                                      // from unit 3
      dl3_head = head;                             //
      dl3_Old_head = Old_head;                     ///
      dl0_cnr = Cylinder_nr;                       ////
      dl3_Old_Cyl_nr = Old_Cyl_nr;                 ///// save dl1
      switch(RL_Nr) {
      case 0:                                     //  to Unit 0
          head = dl0_head;
          Old_head = dl0_Old_head;
          Cylinder_nr = dl0_cnr;
          Old_Cyl_nr = dl0_Old_Cyl_nr;
          BASE = RL0_base;break;
      case 1:                                     //  to Unit 1
          head = dl1_head;
          Old_head = dl1_Old_head;
          Cylinder_nr = dl1_cnr;
          Old_Cyl_nr = dl1_Old_Cyl_nr;
          BASE = RL1_base;break;
      case 2:                                     //  to Unit 2
          head = dl2_head;
          Old_head = dl2_Old_head;
          Cylinder_nr = dl2_cnr;
          Old_Cyl_nr = dl2_Old_Cyl_nr;
          BASE = RL2_base;break;
      }
     }break;
     //---------------------------------------------------------
   }
   //
   RL_Nr_old = RL_Nr;
   RL_match_old = RL_match;
}
//
void readwlan(void)
{
	char *wlanfile = "ESP8266.CFG";
	FRESULT FResult;
	FIL     hFile;
	char EineZeile[100];
	//
	printf ("\n\r>>  Read from file %s \n\r", wlanfile);
	//
	FResult = f_open(&hFile, wlanfile, FA_READ);
	if (FResult != FR_OK) {
	   printf ("\n\n\r\x07 ERROR opening WLAN config file ESP8266.CFG \n\n\r");
	   while(1);
	}
	while ((f_eof(&hFile) == 0)) {
		  f_gets(EineZeile, sizeof(EineZeile), &hFile);  // read EineZeile
		  if (EineZeile[0] =='#'){
		     printf ("%s", EineZeile);
		  }else if (EineZeile[0] =='*'){
			  printf ("%s", EineZeile);
			  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);               // PIO via NIOS-control
			  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0xFFFF);               // All DE10 LED's ON
			  while ((IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x4000 ));   // Wait, until Button_2 = pressed
			  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0);                  // All DE10 LED's OFF
		  }else{
			 printf ("Send to ESP8266> %s", EineZeile);
			 fprintf(fp, "%s", EineZeile);
			 longdelay(900000);
		  }
	}
	FResult = f_close(&hFile);
}
//
void esp8266output()
 {
  int timeout, count;
  char string[1024]="";
  count = 0;
  timeout=0;
  //
  while (timeout  <= 300000)
   {
   if (( IORD_ALTERA_AVALON_UART_STATUS(UART_1_BASE) & 0x0080))
    {
	  c = (IORD_ALTERA_AVALON_UART_RXDATA(UART_1_BASE));
	  string[count] = c;
	  count++;
	  timeout = 0;
    }else{
	  timeout++;
    }
  }
  printf("%s",string);
}
//
void print_sector(void){
 int j;
 printf("\n\r+----------------------------------------------------------------+\n\r");
 for (j = 0; j < 256; j++ ) {
    printf("%c",SECTOR.rl02c[j]);
 }
 printf("\n\r|----------------------------------------------------------------|\n\r");
}
//
void print_RAM(void){
  int j;
  j=RAM_Address;
  printf("\n\r+...............................................................+\n\r");
   for (j = RAM_Address; j < RAM_Address+256; j++ ) {
      printf("%c",RLDRIVE.rl_drive_c[j]);
   }
   printf("\n\r|...............................................................|\n\r");
}
//
//
//================================================================================================
//=============================================== main ===========================================
//================================================================================================
//
int main(void)
{
  short int count=0, errcount=0;
  unsigned int pio, wlanmode;
  unsigned short int rl_status;
  //
  //
  Old_Cyl_nr = 0; head=0; Old_head=0;
  //
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, mode);                        // Clear PIO-0
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);                        // Clear PIO-1
  //fp = fopen ("/dev/uart_1", "r+ | O_RDWR | O_NONBLOCK | O_NOCTTY");    // Open file for reading and writing
  IoInit();
  startup_leds();
  //check_SD_Card();
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x08)) {              // SW_5 @ I_ctrl[3]
    RL = 1;                                                              // RL02
  } else {
    RL = 0;                                                              // RL01
  }
  //
  printf("\n\r\x1B[2J      *********>  DEC RL01/RL02 EMULATOR  <********* \n\r");
  printf("      DE10-Lite board/MAX10-FPGA based Version V.2.2            \n\r");
  printf("                   (c) WWW.PDP11GY.COM                          \n\r");
  //
  //
  //=========================================================================================================
  //
  if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x20000)) {          // WLAN ? -> Switch_8 @ I_ctrl[17]
   	printf ("\n\r              >>>>>    WLAN = active  <<<<<\n\n\r");
   	WIFI=1;
   	fp = fopen ("/dev/uart_1", "r+ | O_RDWR | O_NONBLOCK | O_NOCTTY");   // Open file for reading and writing
   	//
   	fprintf(fp, "AT+RST\r\n"); longdelay(800000);                        // Reset ESP8266
   	printf("ESP8266 IP-Adress:\n\r ");
   	fprintf(fp, "AT+CIFSR\r\n");                                         // AT+CIFSR : Shows the IP and MAC of the module
   	esp8266output();
   	//
    wlanmode = (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0xC0000));   // Get WLAN-Mode
     switch(wlanmode) {
      case 0x40000:                                                      // WLAN dialog mode SW2=on, SW1=off
        printf("\r\n  WLAN dialog mode, please enter ESP8266 commands");
        printf("\n\r             Exit = <Esc> or SW-2 = OFF\n\r\n\r ");
        printf("\n\r>>");
        while((( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x40000)) && ( c != '\x1B'))
        {
        c=getc(stdin);
       	printf("%c",c);
       	fprintf(fp, "%c", c);
       	if(c == 13) {
       	  fprintf(fp, "\r\n");
       	  esp8266output();
       	  printf("\n\n>>");
          }
        }
        printf ("\r\r\n\r\n\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        printf ("\r              >>> WLAN  dialog mode END <<<");
        break;
       //
       case 0x80000:                                                      // WLAN read file mode SW2=off, SW1=on
  	   check_SD_Card();
  	   readwlan();
  	   break;
       //
       default:                                                           // all other WLAN settings
    	printf ("\n\r              >>>>  WLAN default mode  <<<<");
       break;
     }
     //
     fprintf(fp,"      **********  DEC RL01/RL02 EMULATOR  ********** \n\r");
     fprintf(fp,"      DE10-Lite board/MAX10-FPGA based Version V.2.2 \n\r");
     fprintf(fp,"                   (c) WWW.PDP11GY.COM \n\r");
     //
  }else{
	 printf ("\n\r              >>>>>      WLAN = OFF   <<<<<");
  }
  //
  //=========================================================================================================
  //
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x2000)) {         // New @ I_ctrl[13]
    DEBUG = 1;
    printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
  } else {
    DEBUG = 0;
    printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
  }
  //
  if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x10000)) {                        // Switch_6 @ I_ctrl[16]
  	selmode = 1;                                                                       // set select mode Flag
  	printf ("\n\r              >>>>> Select mode = ON  <<<<<");
  	myfile2 = "RL01_0-0.DEC";
  	myfile3 = "SN0.TXT";
  	myfile4 = "RL0.TXT";
  	rlname = IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x00F00000;
  	switch(rlname){
  	  case 0x00000000: myfile2[7] = '0';myfile3[2] = '0';myfile4[2] = '0';break;
  	  case 0x00100000: myfile2[7] = '1';myfile3[2] = '1';myfile4[2] = '1';break;
  	  case 0x00200000: myfile2[7] = '2';myfile3[2] = '2';myfile4[2] = '2';break;
  	  case 0x00300000: myfile2[7] = '3';myfile3[2] = '3';myfile4[2] = '3';break;
  	  case 0x00400000: myfile2[7] = '4';myfile3[2] = '4';myfile4[2] = '4';break;
  	  case 0x00500000: myfile2[7] = '5';myfile3[2] = '5';myfile4[2] = '5';break;
  	  case 0x00600000: myfile2[7] = '6';myfile3[2] = '6';myfile4[2] = '6';break;
  	  case 0x00700000: myfile2[7] = '7';myfile3[2] = '7';myfile4[2] = '7';break;
  	  case 0x00800000: myfile2[7] = '8';myfile3[2] = '8';myfile4[2] = '8';break;
  	  case 0x00900000: myfile2[7] = '9';myfile3[2] = '9';myfile4[2] = '9';break;
  	  case 0x00A00000: myfile2[7] = 'A';myfile3[2] = 'A';myfile4[2] = 'A';break;
  	  case 0x00B00000: myfile2[7] = 'B';myfile3[2] = 'B';myfile4[2] = 'B';break;
  	  case 0x00C00000: myfile2[7] = 'C';myfile3[2] = 'C';myfile4[2] = 'C';break;
  	  case 0x00D00000: myfile2[7] = 'D';myfile3[2] = 'D';myfile4[2] = 'D';break;
  	  case 0x00E00000: myfile2[7] = 'E';myfile3[2] = 'E';myfile4[2] = 'E';break;
  	  case 0x00F00000: myfile2[7] = 'F';myfile3[2] = 'F';myfile4[2] = 'F';break;
  	}
  }else{
	selmode = 0;                                                                       // clear select mode Flag
	printf ("\n\r              >>>>> Select mode = OFF <<<<<");
	myfile2 = "RL01_0.DEC";
	myfile3 = "SN.TXT";
	myfile4 = "RL.TXT";
  }
  //
  if (RL == FALSE){
    rl_status = RL01_OK;
    SDRAM = 5898240;
    MAXCYL = RL01_size;
    myfile2[3] = '1';
    printf ("\n\r              >>>>> Device Type = RL01 <<<<\n\r");
  } else {
    rl_status = RL02_OK;
    SDRAM = 11796480;
    MAXCYL = RL02_size;
    myfile2[3] = '2';
    printf ("\n\r              >>>>> Device Type = RL02 <<<<\n\r");
  }
  //
   RL_unit = (IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE)>>4) &~0xFFF0;
   printf ("\n\r     Configurated RL01/RL02 Unit(s): ");
   if(RL_unit & 0x0001) {
	   printf ("DL0: ");
	   dl0=1;
   }
   if(RL_unit & 0x0002) {
	   printf ("DL1: ");
	   dl1=1;
   }
   if(RL_unit & 0x0004) {
	   printf ("DL2: ");
	   dl2=1;
   }
   if(RL_unit & 0x0008) {
	   printf ("DL3: ");
	   dl3=1;
   }
   printf ("\n\r");
  //
  //
  PRESET_one_SECTOR();                                                     // First-INIT
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, count);                          // Clear PIO-0
  //
  //
  // A) Check for OFFLINE Mode ( SWITCH 01 @ I_ctrl[11] )
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x1000)) {              // New @ I_ctrl[12]
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);                      // LED Status indicator
     //
     OFFLINE = 1;                                                          // ###########  OFFLINE-Mode #############
     //
     make_offline_track0();                                                // construct one track in memory/union
     //
     if(dl1 == TRUE) {
       printf ("\n\r         copy  dl0_RAM-area  to  dl1_RAM-area:  ");
       DEST=RL1_base;
       memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM );                         //NEW
     }
     if(dl2 == TRUE) {
       printf ("\n\r         copy  dl0_RAM-area  to  dl2_RAM-area:  ");
       DEST=RL2_base;
       memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM );                         //NEW
     }
     if(dl3 == TRUE) {
       printf ("\n\r         copy  dl0_RAM-area  to  dl3_RAM-area:  ");
       DEST=RL3_base;
       memcpy(&RLDRIVE.rl_drive_i[DEST], &RLDRIVE.rl_drive_i[BASE], SDRAM );                         //NEW
     }
     SN_default();                                                                                   // PreSet SN's to default
     //
     //
  } else {
	  //
      OFFLINE = 0;                                                          // ########### ONLINE-Mode ##########
      //
      printf ("\n\r              ******** ONLINE MODE ********\n\r");
      //
      check_SD_Card();                                                      // ONLINE mode needs SD-Card
      //
      if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04)) {            // Only in NON reformat mode
    	  printf("\n\r *******************************************************************\n\r\n");
          check_ID();
          printf("\n\r *******************************************************************\n\r");
      }
      //
      // B) Check for SD card Format Request ( SWITCH 00 @ I_ctrl[2])                                                // Online mode only possible with SD-Card
      //
      if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04)) {       // (RE)Format SD card ?
    	printf ("\n\r Construct RL01/RL02 cartridge format on SD_Card  \n\r");
    	if (selmode == FALSE) {
          printf ("  Switch-1 is ON , Reformat SD-Card with FAT32    \n\r");
          printf ("       Insert SD-Card and reset Switch-1    \n\r\n");
          while (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04));
          printf ("  Step 1 of 6 : Test interface ..... ");
          printf("done! \r\n");
          printf ("  Step 2 of 6 : Reformat SD-Card with FAT32... ");
          make_FAT32_on_SD_Card();
          printf ("done!\n\r");
          //
          printf ("  Step 3 of 6 : Test SD-Card: \n\r");
          make_myfile_on_SD_Card();
    	} else {
    		printf ("       Insert SD-Card and reset Switch-1    \n\r\n");
    	    while (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04));
    		printf ("      Select mode : Step 2 and 3 skipped   \n\r");
    	}
        //
        printf ("Step 4 of 6 : Construct RL01/RL02 cartridge format in RAM \n\r");
        make_rl_structure_in_ram();
        //
        printf ("\r\n  Step 5 of 6 : Clone DL0-RAM area to: ");
        printf ("DL1:  ");
        memcpy(&RLDRIVE.rl_drive_i[RL1_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
        printf ("DL2:  ");
        memcpy(&RLDRIVE.rl_drive_i[RL2_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
        printf ("DL3:  ");
        memcpy(&RLDRIVE.rl_drive_i[RL3_base], &RLDRIVE.rl_drive_i[BASE], SDRAM );
        //
        if(selmode == TRUE){
           make_infofile_on_SD_Card();
        }
        SN_default();             // **** Pre-SET Cartridges Serial Numbers ****
        SN_write();               // Write Serial Numbers to SD-Card in file SNx.TXT
        SN_read();                // Read SN's from SD-Card and rebuild data CRC
        //
        printf ("\r\n  Step 6 of 6 : Dump RAM to SD-Card into file:");
        //
        PRESET_one_SECTOR();
        WRITE_to_SD_Card();
        //
        //
        //                                                                       // *******************************************
      }else {                                                                    // ************ Start normal *****************
        //                                                                       // *******************************************
        //
        // C) Check for connected RL controller , Power OK Signal @ I_ctrl[0]
          if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x01)){
            IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);
            printf("\n\r\x07\x1B[2J");  // VT100 EScape Sequenze : Clear_screen
            printf("\n\r               System start not possible !      ");
            printf("\n\r              No connection to RL controller    ");
            printf("\n\r               Restart system and try again     ");
            while(1);
          } else {
          printf ("          Read configured RL-units from SD-Card  \n\r");
          //check_ID();  // hier gehts
          //
          //
          READ_from_SD_Card();
           if (SECTOR.rl02l[127] != 0x45444E45 ) {
              printf("\n\n\rSD-Card with illegal format detected !");
              printf("\n\r               Restart system and try again     ");
              while(1);
           }
         }
      }
   }
   //
   //
   mode = 0x4001;                                           // = start conditions set up
   IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);           // Start, Step #1of2 = ENABLE interface
   //
   RL_match = (IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE)>>8) &~0xFFF0; // get current unit-Nr.
   switch(RL_match) {
     case 0x0001:
 	   RL_Nr = 0;
 	   BASE = RL0_base;break;
     case 0x0002:
 	   RL_Nr = 1;
 	   BASE = RL1_base;break;
     case 0x0004:
 	   RL_Nr = 2;
 	   BASE = RL2_base;break;
     case 0x0008:
 	   RL_Nr = 3;
 	   BASE = RL3_base;break;
   }
   //
   if(usingdefault == FALSE) { SN_read(); }               //     Read +  SN's if available + rebuild CRC
   SN_print();
   //
   RL_Nr_old = RL_Nr;               // Preset
   RL_match_old = RL_match;         // Preset
   RAM_Address = BASE;              // Preset
   Old_RAM_Address = RAM_Address;   // Preset
   if(DEBUG == TRUE) {
     printf("\n\r                   selected unit: %d ", RL_Nr );
   }
   //
   // Cylinder_nr*CYL_size) + BASE + head
   //                                                             ##################
   WRITE_drive_to_FPGA(RAM_Address );//                           ### RAM-->FPGA ###
   //                                                             ##################
   //
   //================================================================================================
   printf("\r\n ************ S T A R T RL01/RL02-Simulator ************* \n\r");
   if(WIFI==TRUE){ fprintf(fp,"\r\n ************ S T A R T RL01/RL02-Simulator ************* \n\r");}
   //================================================================================================
   errcount=0;
   send_drive_info(rl_status);
   IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode|0x00A0));    // Output Enable + Drive Ready
   if(DEBUG == TRUE) {
     printf(" Started with operating mode:            ");
     print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
   }
   //
   //
   //
   //                                           ��������������������������
   while(1){       //                           �������  MAIN LOOP �������
    //                                          ��������������������������
    //
	//
	//---------------------------------------------------------------------------------------------------------------------
	// 1)NEW: Check if Unit-Number has been changed      AND
    //        Check if new/changed Unit-Number is also configured
	RL_match = (IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE)>>8) &~0xFFF0;
	if((RL_match != RL_match_old) & ((RL_unit & RL_match) == RL_match)) {
		//
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode | 0x0010));          // Set drive to NOT ready @O_ctrl[4]
		RL_drive_nr_changed=TRUE;                                               // indicate
		//
		//get new Unit-Number
	    switch(RL_match) {
	       case 0x0001: RL_Nr = 0; break;
	       case 0x0002: RL_Nr = 1; break;
	       case 0x0004: RL_Nr = 2; break;
	       case 0x0008: RL_Nr = 3; break;
	    }
	    if(DEBUG == TRUE) {
	      if(WIFI==FALSE){
	        printf("\n\r*********************************************");
	        printf("\n\r****  Current RAM_Address =   %d ", RAM_Address );
	        printf("\n\r****  Switch Unit Number from  %d ", RL_Nr_old );
	        printf(" to %d   **** ", RL_Nr );
	      }else{
	    	fprintf(fp,"\n\r*********************************************");
	    	fprintf(fp,"\n\r****  Current RAM_Address =   %d ", RAM_Address );
	    	fprintf(fp,"\n\r****  Switch Unit Number from  %d ", RL_Nr_old );
	    	fprintf(fp," to %d   **** ", RL_Nr );
	      }
	    }
	    READ_drive_from_FPGA(RAM_Address);                                      // Save FPGA/DPR into RAM
	    RAM_align();
	    RAM_Address = (Cylinder_nr * CYL_size) + head + BASE;                   // Calculate new RAM Address
	    WRITE_drive_to_FPGA(RAM_Address);                                       // Write RAM-part to FPGA/DPR
	    if(DEBUG == TRUE) {
	      if(WIFI==FALSE){
	        printf("\n\r****  New RAM address : %d", RAM_Address);
	        printf("\n\r*********************************************");
	      }else{
	    	fprintf(fp,"\n\r****  New RAM address : %d", RAM_Address);
	    	fprintf(fp,"\n\r*********************************************");
	      }
	    }
	    //
	    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode &~ 0x0010));        // Set drive to NOT ready @O_ctrl[4]
	    //
	 }
	//---------------------------------------------------------------------------------------------------------------------
    // 2) check for drive command @ I_ctrl[1]
	//
    if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x0002)) {         // test @ I_ctrl[1]
      if(RL_drive_nr_changed==FALSE) {                                 // No UNIT Change
    	 //
         //
         pio = IORD_ALTERA_AVALON_PIO_DATA(PIO_0_BASE);                // get command > pio
         if(DEBUG == TRUE){
           printf("\n\rDrive command received: ");
           print_binary_16bit_LSB(pio);
         }
         if(RL == 0) {
           pio = pio &~0x8000;                                       // RL01 !!
             if(DEBUG == TRUE){
               printf("\n\r  Drive command modified: ");
               print_binary_16bit_LSB(pio);
             }
         }
         //
         Cylinder_nr_diff = (pio >>7);                                 // get Cylinder Address-Difference
         //
         if(pio & 0x0010){                                             // get head number & define offset
             head = DPR_size; } else { head = 0;                       // Bit 04 = Head select
         }
         if(DEBUG == TRUE) {
        	if(WIFI==FALSE){
              printf("\n\r  Cylinder address difference : %d ", Cylinder_nr_diff );
        	}else{
        	  fprintf(fp,"\n\r  Cylinder address difference : %d ", Cylinder_nr_diff );
        	}
         }
         if(head == 0){
            rl_status = (rl_status &~ 0x0040);                         // Indicate: head 0 in use
           } else {
            rl_status = (rl_status |  0x0040);                         // indicate: head 1 in use
         }
         send_drive_info(rl_status);
         //
         if((Cylinder_nr_diff == 0) & (head == Old_head)) {
            acknowledge();                                             // all done
            if(DEBUG == TRUE){printf("\n\r     Request with no action    ");}
         } else {
           if(DEBUG == TRUE){
             if((head != Old_head) & (head == DPR_size)) {
              if(WIFI==FALSE){
                printf("   Using head 1   ");
              }else{
            	fprintf(fp,"   Using head 1   ");
              }
             }else{
              if(WIFI==FALSE){
            	printf("   Using head 0   ");
              }else{
            	fprintf(fp,"   Using head 0   ");
              }
         }
         //                                                           // ##################
         READ_drive_from_FPGA(Old_RAM_Address);                       // ### FPGA-->RAM ###
         //                                                           // ##################
         //
         if(pio & 0x0004){
            // 1= move heads toward spindle
            Cylinder_nr = (Cylinder_nr + Cylinder_nr_diff) ;
         } else {
            // 0= move heads away from spindle
            Cylinder_nr = (Cylinder_nr - Cylinder_nr_diff);
         }
         //
         //
         if(Cylinder_nr < 0) {
        	 errcount++;
        	 if(errcount > 4){
        		printf("\n\n\n\r >>>           Fatal Error        <<<<");
        		printf("\n\r >>> New physical cylinder is negativ  %d ", Cylinder_nr );
        		printf("\n\r >>>           System halt         <<<");
        	    while(1);
        	 }else{
    	        printf("\n\r >>>              Error         <<<");
    	        printf("\n\r >>> New physical cylinder is negativ  %d ", Cylinder_nr );
    	        printf("\n\r >>>             Recover         <<<");
    	        Cylinder_nr = 0;
    	        RAM_Address = BASE;
        	 }
         }else{
            //
            // Calculate index for RAM/union
            RAM_cyl_addr = (Cylinder_nr * CYL_size);
              if(DEBUG == TRUE) {
                 if(WIFI==FALSE){
                   printf("\n\r   New cylinder address:     %d ", RAM_cyl_addr );
                   printf("\n\r   Point to track address:   %d ", RAM_cyl_addr + head );
                 }else{
            	   fprintf(fp,"\n\r   New cylinder address:     %d ", RAM_cyl_addr );
            	   fprintf(fp,"\n\r   Point to track address:   %d ", RAM_cyl_addr + head );
                 }
               }
            RAM_Address = BASE + RAM_cyl_addr + head;                // Calculate new RAM address
            // restart cycle = read selected track from RAM into FPGA/DPR
           }
          }
          //
          //                                                          // ##################
          WRITE_drive_to_FPGA(RAM_Address);                           // ### RAM-->FPGA ###
          //                                                          // ##################
          //
          Old_head  = head;                                           // Save
          Old_Cyl_nr = Cylinder_nr;                                   // Save
          }
          Old_RAM_Address = RAM_Address;                              // Save
          //
          acknowledge();                                              // All done ...indicate
          //
          //
      }else{                                                         // UNIT Change
    	 Old_RAM_Address = RAM_Address;                              // Save RAM-Address
         if(head == 0){
           rl_status = (rl_status &~ 0x0040);                        // Indicate: head 0 in use
         } else {
           rl_status = (rl_status |  0x0040);                        // indicate: head 1 in use
         }
         rl_status = (rl_status |  0x0200);                          // set Volume-Check
         send_drive_info(rl_status);
         acknowledge();
         rl_status = (rl_status &~ 0x0200);                          // clear Volume-Check
    	 RL_drive_nr_changed=FALSE;                                  // Unit-Change done.
      }
    }
    //
    //
    //------------------------------------------------------------------------------------------------------------------
    // 3) check if Reconfiguring unit button was pressed
    if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x4000)) {                    // Button_2 @ I_ctrl[14]
       while (!(IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x4000 ));                // Wait, until Button_2 = released
       RL_unit = (IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE)>>4) &~0xFFF0;
       printf ("\n\r\n Reconfigurated RL01/RL02 Unit(s): ");
       if(RL_unit & 0x0001) {
    	   printf ("DL0: ");
    	   dl0=1;
       }
       if(RL_unit & 0x0002) {
    	   printf ("DL1: ");
    	   dl1=1;
       }
       if(RL_unit & 0x0004) {
    	   printf ("DL2: ");
    	   dl2=1;
       }
       if(RL_unit & 0x0008) {
    	   printf ("DL3: ");
    	   dl3=1;
       }
       printf ("\n\n\r");
    }
    //------------------------------------------------------------------------------------------------------------------
    //
    //
    //------------------------------------------------------------------------------------------------------------------
    // 4) check for power fail or reset
    if ( (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x8000)) |        // Reset @ I_ctrl[15]   ?
      (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x01)) )            // Power-OK @ I_ctrl[0] ?
      {
      delay(4000);                // wait
      while (!(IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x8000 ));      // Release Reset switch?
      if( OFFLINE == FALSE ) {
          printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
          //
          READ_drive_from_FPGA(Old_RAM_Address);                         // Save
          Old_Cyl_nr = 0;
          IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0000);               // Clear PIO-0
          IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);               // Clear PIO-1
          //....save
          WRITE_to_SD_Card();                                            // SAVE to SD-Card
          //
      } else {
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0000);                 // Clear PIO-0
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);                 // Clear PIO-1
         printf("\x07\n\n\r        *** System switched down *** \n\r");
      }
      printf("\x07\n\r        Press RESET button for restart \n\r");
      IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);
      while(1);
    }
  }
  return 0;
}
