
                                            DE10-Lite/MAX10 RL01/02-Emulator

      Version V2.2: Source-kit upgrade
      ******************************** 

      Replace all these files/folders in the unziped project folder  MAX10_RL_Emulator
                           from the file MAX10_RL_Emulator_V1_5.zip



                    www.pdp11gy.com   info@pdp11gy.com