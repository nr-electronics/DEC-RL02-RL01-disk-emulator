         Instructions for loading & flashing  MAX10/DE10-Lite-Board
            running the RL01/RL02 disk simulator on it.


-  Make sure, your USB connection to the DE1-Board is working.
-  Serial-Speed =  19200 Baud
 	 

          **************************************************************


-  If You want to load the design to RAM, use: ./myload.sh
   -  In Windows: Start the Nios2 Command Shell , EDS 15.1sp2 [GCC 4]
 	          ( location:  \altera\11.1sp2\nios2eds )

Info: you also can flash  the firmware permanent using the file RL_emulator.pof
      located in the folder "in_RAM" . Now you can  compile the C file with 
      eclipse-nios2


          **************************************************************

  
- If you want to make the design permanent, booting from the onchip_flash:
  -  start the Quartus ( Prime 16.1 lite Edition ) 
  -  Navigate to Tools/Programmer
  -  start Auto Detect and select 10M50DA
  -  right mouse click to "10M50DA" and select Change file
  -  select the .pof-file, in this case: flash/in_onchip_flash/MAX10_RL_emulator.pof
  -  Select the file @ Program/Configure and Press Start
     ...... flashing ........
  -  re-power the MAX10 DE10-Lite board.

