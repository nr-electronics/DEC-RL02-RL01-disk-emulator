#include <stdio.h>
#include <string.h>
//
//
//
//
#define DPRAM_BASE 0x90000000                   // !!!!!!! Base-Address Dual-Ported-Ram !!!!!!!!!
#define DPRAM DPRAM_BASE                        //             assigned to "DPRAM"
//
#define RAMi  5760                              // Used RAM-Size integer
#define RAMs 11520                              // Used RAM-Size short integer
#define RAMb 23040                              // Used RAM-Size byte
#define SEC_size_c 288                          // byte:    Sector size, including header/crc/servo  8Bit
#define SEC_size_i 144                          // integer: Sector size, including header/crc/servo 16Bit
//
void delay(unsigned short wait);
void PRESET_one_SECTOR(void);
//
//--------------------------------------------------
union rld {                                       // ****** one RL01/2 sector *************
       unsigned char  rl02c[512];                 // Access to one Sector via 296 bytes or
       unsigned short rl02i[256];                 // 144 16Bit words  , alligned to 512/256
       unsigned int   rl02l[128];
};
union  rld SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rld *u_rl02ptr;                            // pointer to union.
//--------------------------------------------------
union rlt {
       unsigned char  rl_drive_c[RAMb];           // ***** RL02 Structure @ SD-RAM/=union ********
       unsigned short rl_drive_i[RAMs];           // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rl_drive_l[RAMi];           // 2* 40 sectors = 11520 16 bit * 512 = 5898240/unit
};
//union  rlt RLDRIVE;                             // define a union of type RLDRIVE
union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
union  rlt *u_rl02_drive_ptr;                     // pointer to union
//--------------------------------------------------
unsigned short int header_index =    3;           // Header index =3
unsigned short int data_start =     10;           // + 7, = +header=3 +PD1=1 +PR2=3
unsigned short int data_CRC =      138;           // + 135
//
//
//
void delay( unsigned short wait)
{
     while (wait) {
           wait = wait -1;
     }
}
//
//
void PRESET_one_SECTOR(void) {
  // initialize data for one sector used for test and reference purpose.
  int i;
  header_index = 3;                                                   // **** Set ****
  data_start = header_index + 7;                                      // **** Set ****
  data_CRC = header_index + 135;                                      // **** Set ****
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x8000,                                           //  PR1,header_index=3
    0x0000, 0x0000, 0x0000,                                           //  Header
    0x0000,                                                           //  PD1
    0x0000, 0x0000, 0x8000,                                           //  PR2
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x4C52, 0x3230, 0x532D, 0x4D49, 0x4C55,   //  Data 66-73
    0x5441, 0x524F, 0x5620, 0x4E4F, 0x5220, 0x4945, 0x484E, 0x5241,   //  Data 74-81
    0x2044, 0x4548, 0x4255, 0x5245, 0x4547, 0x0A52, 0x520D, 0x304C,   //  Data 82-89
    0x2D32, 0x4953, 0x554D, 0x414C, 0x4F54, 0x2052, 0x4F56, 0x204E,   //  Data 90-97
    0x4552, 0x4E49, 0x4148, 0x4452, 0x4820, 0x5545, 0x4542, 0x4752,   //  Data 98-105
    0x5245, 0x0D0A, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 106-113
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x3A33,                                                           //  Data 128 = CRC
    0x0000,                                                           //  129 = PD2
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 }; //  146-153=Zero
  //
  //
  for (i = 0; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }             // clear buffer
  for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }        // Load buffer
  //make_data_CRC();
    SECTOR.rl02l[100]=0x2E575757; // "WWW."
    SECTOR.rl02l[101]=0x31504450; // "PDP1"
    SECTOR.rl02l[102]=0x2E594731; // "1GY."
    SECTOR.rl02l[103]=0x204D4F43; // "COM "
    SECTOR.rl02l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
int main()
{
  int i;
  PRESET_one_SECTOR();
  printf("\n\r        One SECTOR preset done  \n\r ");
  printf("\n\r      DE0-Nano-SoC : UART-Test-Loop    \n\r ");
  while(1){
	for (i = 0; i < 200; i++ )  {
		  //
		  printf("\n\r copy onchip_ram --> DPR :");
		  delay(30000);                // wait
		  memcpy((void *)(DPRAM), &RLDRIVE.rl_drive_i[0], SEC_size_c * 40);
		  //
		  printf("\n\r copy DPR --> onchip_ram :");
		  delay(30000);                // wait
		  memcpy(&RLDRIVE.rl_drive_i[0], (void *)(DPRAM), SEC_size_c * 40);
		  //
	      printf("\n\r Count &  Hallo vom UART @ 19200 Baud    %d" , i);
	}
  }
  return 0;
}
