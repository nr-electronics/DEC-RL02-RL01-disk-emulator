

         Instructions for loading & flashing  DE0-Nano_SoC board
            running the RL01/RL02 disk emulator on it


-  Make sure, your USB connection to the DE0-Nano_SoC is working.
-  Serial-Speed =  19200 Baud
 	 

    


