#!/bin/sh

#

#  Copyright (C) 2013 by Reinhard Heuberger , www.pdp11gy.com

#
echo ""

echo ""

echo "         **** load the design into memory **** "

echo ""

echo "         1) load the sof-file...."


jtagconfig

nios2-configure-sof ./in_RAM/rl02_simulator_v3.sof

echo ""

echo "         2) load the elf-file...."

nios2-download -g ./in_RAM/DE0_RL_Emulator_V5.elf


echo ""

echo "                finished "
echo ""

