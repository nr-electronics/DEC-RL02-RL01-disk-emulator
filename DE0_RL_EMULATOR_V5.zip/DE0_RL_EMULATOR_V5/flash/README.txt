         Instructions for loading & flashing  DE0-Nano-Board
            running the RL01/RL02 disk simulator on it


-  Make sure, your USB connection to the DE0-Board is working.	 
-  In Windows: Start the Nios2 Command Shell , EDS 13.1sp2 [GCC 4]
 	          ( location:  \altera\13.1sp2\nios2eds )                  
-  Navigate to the unziped flash directory with command cd. 
-  A ls command should get following result:
	  flash_example.txt  in_RAM            myelf.flash  myload.sh
 	  in_EPCS            load_example.txt  myflash.sh   mysof.flash
-  If You want to load the design to RAM, use: ./myload.sh
     > Example/reference:  load_example.txt 
-  If You want to flash the design, make it permanent, use: ./myflash.sh
     > Example/reference:  flash_example.txt 

        Feedback, if You want:  Reinhard.Heuberger@pdp11gy.com

Note ! 
Unfortunately, the flash program does not work with version 15 or 16 "
Please use the flash program of version 13.1 or 14.0 "