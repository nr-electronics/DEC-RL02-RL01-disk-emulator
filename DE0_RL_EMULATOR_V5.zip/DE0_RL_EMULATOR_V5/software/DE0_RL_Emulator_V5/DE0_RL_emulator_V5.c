/*
              *****************************************************************************
              *  Copyright (C) 2017 by Reinhard Heuberger                                 *
              *                                                                           *
              *  All rights reserved.                                                     *
              *                                                                           *
              *  Redistribution and use in source and binary forms, with or without       *
              *  modification, are permitted provided that the following conditions       *
              *  are met:                                                                 *
              *                                                                           *
              *  1. Redistributions of source code must retain the above copyright        *
              *     notice, this list of conditions and the following disclaimer.         *
              *  2. Redistributions in binary form must reproduce the above copyright     *
              *     notice, this list of conditions and the following disclaimer in the   *
              *     documentation and/or other materials provided with the distribution.  *
              *  3. Neither the name of the author nor the names of its contributors may  *
              *     be used to endorse or promote products derived from this software     *
              *     without specific prior written permission.                            *
              *                                                                           *
              *****************************************************************************
                                        RL02 Simulator
                                        Version V.3.05
                                     based on DE0-Nano Board
                           by: Reinhard Heuberger , www.PDP11GY.com


                                 Data - Structure and Mapping:

                         |<---- 8 MB onboard SD RAM ----->|      |<- DP-RAM-->|

              / 5.898240 +-------------+
             /           |Cylinder #511|
   +--------+   5.886720 +-------------+
   |        |            |             |
   |   SD   |            .             .
   |  CARD  |            .             .  /---+------------+    /+------------+
   |        |            |             | /    |  Track #1  |   / |  1 Track   |
   +--------+     11520  +-------------+/     |- - - - - - |--/  | 5760 words |
             \           | Cylinder #0 |      |  Track #0  |     |   DP-RAM   |
              \    0000  +-------------+ - - -+------------+- - -+------------+

        The DEC RL01/RL02 disk drive did have a capacity of 5.2MB/10.4MB
                 2 Heads(surfaces), 256/512 cylinder , 40 sectors/track.
                1 sector contains 128 16-bit words ( 256 Byte ) of Data
        + 12 16-Bit words for Servo/Header/CRC Data = 140 words(280 Byte)/sector.


  SD-Card support is based on the SPI interface from: http://www.emb4fun.de/fpga/fatfs/index.html
     with full FAT32 support using ChaN's FatFs ( http://elm-chan.org/fsw/ff/00index_e.html ).

  History: Version V.3.00 : Migration to Quartus II +  NIOS II Embedded Design SuiteVersion 11.1
           Version V.3.01 : Migration from Altera SOPC to  Altera QSYS
           Version V.3.02 : Add SPI interface to get full FAT32 support for SD-Card via ChaN's FatFs
           Version V.3.03 : Firmware changes/bug fixes ( simultaneously copy/device) + improvements
           Version V.3.04 : Speed improvement. DPR is now included in QSYS. Result: A memcpy is
                            replacing the previously used PIO based controlled I/O. Offline mode will
                            now construct Cylinder 0+1 and the bad sector file in memory.
   -----------------------------------------------------------------------------------------------------
          Version V5.00 : Same code, but with other PIN-layout using the general RL Interface,
                           connected to J4 @ BeMicro ( JAN 2017 ) @Version Quartus V15.1
                MAR 2017 : Ported to Quartus Version V16.1
                MAI 2017 : Ported to CMM PCB board pinout.




*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <system.h>
#include <sys/alt_alarm.h>
#include <io.h>
#include "fatfs.h"
#include "diskio.h"
#include "ff.h"
#include "altera_avalon_pio_regs.h"

void delay(unsigned short wait);
void PRESET_one_SECTOR(void);
void startup_leds(void);
void delay(unsigned short wait);
void print_binary_16bit_LSB( unsigned short ibit16);
void LSB_print_binary_16bit( unsigned short ibit16);
void print_binary_8bit( unsigned char cbit8 );
void PRESET_one_SECTOR(void);
void make_header_CRC(void);
void make_data_CRC(void);
void print_sector(void);
void make_bad_sector_file(void);
void make_offline_track0(void);
void make_rl_structure_in_ram(void);
void make_bootsector(void);
void WRITE_drive_to_FPGA(int point_to_track);
void READ_drive_from_FPGA(int point_to_track);
void get_header_infos(void);
void send_drive_info( unsigned short infodrive);
void acknowledge(void);
void check_SD_Card(void);
void make_FAT32_on_SD_Card(void);
void make_myfile_on_SD_Card(void);
void WRITE_to_SD_Card(void);
void READ_from_SD_Card(void);
//
#define DPRAM_BASE 0x00100000
#define DPRAM DPRAM_BASE
//
//#########################################################################################################
//                                            SD-CARD & FAT32
static FATFS Fatfs;
static alt_alarm alarm;
static unsigned long Systick = 0;
static volatile unsigned short Timer;   // 1000Hz increment timer

static alt_u32 TimerFunction (void *context)
{
   static unsigned short wTimer10ms = 0;

   (void)context;

   Systick++;
   wTimer10ms++;
   Timer++;

   if (wTimer10ms == 10)
   {
      wTimer10ms = 0;
      ffs_DiskIOTimerproc();  // Drive timer procedure of low level disk I/O module
   }

   return(1);
}

static void IoInit(void)
{
   // Init diskio interface
   ffs_DiskIOInit();
   // Init timer system
   alt_alarm_start(&alarm, 1, &TimerFunction, NULL);
}
//###################################################################################################
//
// Bit 9 = volume check , Bit 7 = Drive Type , Bit 6 = in action current head
#define RL01_OK 0x021D           // Octal:001035 = Drive Status, RL01 is ready/head_0
#define RL02_OK 0x029D           // Octal:001235 = Drive Status, RL02 is ready/head_0
//
#define CYL_size 11520           // One track size, 16Bit words
#define DPR_size 5760            // Dual-Portet-RAM size, 16Bit words
#define RL01_size 255            // RL01 = 256 cylinder ( 0 - 255 )
#define RL02_size 511            // RL02 = 512 cylinder ( 0 - 511 )
#define SEC_size_c 288           // byte:    Sector size, including header/crc/servo  8Bit
#define SEC_size_i 144           // integer: Sector size, including header/crc/servo 16Bit
#define SEC_size_l 72            // long:    Sector size, including header/crc/servo 32Bit
#define TRUE  1
#define FALSE 0
//
/*        *********************** Global Definitions **********************        */
//
union rld {                                       // ****** one RL01/2 sector *************
       unsigned char  rl02c[512];                 // Access to one Sector via 296 bytes or
       unsigned short rl02i[256];                 // 144 16Bit words  , alligned to 512/256
       unsigned int   rl02l[128];
};
//union  rld SECTOR;                              // define a union of type SECTOR
union  rld SECTOR __attribute__ ((aligned(4)));   // define a union of type SECTOR
union  rld *u_rl02ptr;                            // pointer to union.
//
//
union rlt {
       unsigned char  rl_drive_c[11796480];       // ***** RL02 Structure @ SD-RAM/=union ********
       unsigned short rl_drive_i[5898240];        // Virtual access to 512 cylinders(head 0 and 1)
       unsigned int   rl_drive_l[2949120];        // 2* 40 sectors = 11520 16 bit * 512 = 5898240
};
//union  rlt RLDRIVE;                             // define a union of type RLDRIVE
union  rlt RLDRIVE __attribute__ ((aligned(4)));  // define a union of type RLDRIVE
union  rlt *u_rl02_drive_ptr;                     // pointer to union
//
unsigned short int header_index =    3;           // Header index =3
unsigned short int data_start =     10;           // + 7, = +header=3 +PD1=1 +PR2=3
unsigned short int data_CRC =      138;           // + 135
unsigned short int RL_unit  =        0;           // current selected RL unit-number
int SDRAM                   = 11796480;           // maximum used bytes SD-RAM
unsigned short MAXCYL       =      511;           // cylinder, RL01/Rl02
//
short int mode=0;                                 // System operating mode
unsigned char DEBUG=0;                            // DEBUG PURPOSE
unsigned char OFFLINE=0;                          // online/offline mode
unsigned char OFFMODE=0;                          // full/simple offline mode
unsigned char RL=1;                               // 0=RL01 , 1=RL02
//
char *myfile1 = "PDP11GY.TXT";
char *myfile2 = "RL01_0.DEC";
/*************************************************************************************/
//
//
void startup_leds(void)
{
short  is;
short  count = 4;
int laufled = 0x00000001;
    for (count = 0; count < 4; count++ )  {
      IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);
        for (is = 0; is < 16; is++ )  {
          IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, laufled);
            // IOPIN1 = laufled<<16;
            delay(4000);                   // wait
            laufled = laufled <<1;
        }
        IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x8000);   //$$
        for (is = 0; is < 16; is++ )  {
            //IOPIN1 = laufled<<16;
            IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, laufled);
            delay(4000);                // wait
            laufled = laufled >>1;
       }
    }
}
//
void delay( unsigned short wait)
//   Based on Nios II/e core CPU running at 50MHz
// Value wait; 1000=6.6ms  , 500=3.2ms  , 100=0.66ms
{
     while (wait) {
           wait = wait -1;
     }
}
//
//
void print_binary_16bit_LSB( unsigned short ibit16)
// Representation: LSB on right site ( PDP-11 like)
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x8000 & ibit16 ) {               // Test Bit 15
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 << 1;
  }
}
//
//
void LSB_print_binary_16bit( unsigned short ibit16)
// Representation: LSB on left site, = usefull if
//    comparing data with logic-analyser dataflow.
{
 int i;
  for (i = 0; i < 16; i++ ){
       if(0x0001 & ibit16 ) {               // Test Bit 00
          printf("1");
          }
           else {
              printf("0");
           }
   ibit16 = ibit16 >> 1;
  }
}
//
//
void print_binary_8bit( unsigned char cbit8 )
{
 int i;
  for (i = 0; i < 8; i++ ){
       if(0x80 & cbit8 ) {               // Test Bit 7
          printf("1");
          }
           else {
              printf("0");
           }
   cbit8 = cbit8 << 1;
   }
}
//
//
//- calcCRC16r ------------------------------------------------------
unsigned short int calcCRC16r(unsigned short int crc, unsigned short int c, unsigned short int mask)
//
// Note: This smart C-Code was not written by myself.
// Reference: http://www.mikrocontroller.net/topic/12177#2274632
{
  unsigned char i;
  for(i=0;i<8;i++)
  {
    if((crc ^ c) & 1) { crc=(crc>>1)^mask; }
    //if((crc = crc  ^ c) & 1) { crc=(crc>>1)^mask; }
    else crc>>=1;
    c>>=1;
  }
  return (crc);
}
//
//
void PRESET_one_SECTOR(void) {
  // initialize data for one sector used for test and reference purpose.
  int i;
  header_index = 3;                                                   // **** Set ****
  data_start = header_index + 7;                                      // **** Set ****
  data_CRC = header_index + 135;                                      // **** Set ****
  unsigned short mysector[]=
  { 0x0000, 0x0000, 0x8000,                                           //  PR1
    0x0000, 0x0000, 0x0000,                                           //  Header
    0x0000,                                                           //  PD1
    0x0000, 0x0000, 0x8000,                                           //  PR2
    0x0000, 0x0000,                                                   //  Data 00-01
    0xFF00, 0xFF00, 0xFF00, 0xFF00, 0xFF00, 0x0000, 0x0000, 0x0000,   //  Data 02-09
    0x3333, 0x3333, 0x3333, 0x3333, 0x3333, 0x0000, 0x0000, 0x5500,   //  Data 10-17
    0x5555, 0x5555, 0x5555, 0x5555, 0x0055, 0x0000, 0x0000, 0x9249,   //  Data 18-25
    0x4924, 0x2492, 0x9249, 0x0024, 0x0000, 0x0000, 0x9123, 0x23DC,   //  Data 26-33
    0xDC91, 0x9123, 0x00DC, 0x0000, 0x0000, 0x8080, 0x8080, 0x8080,   //  Data 34-41
    0x8080, 0x8080, 0x0000, 0x0000, 0xE700, 0xF39C, 0x9CE7, 0xE7F3,   //  Data 42-49
    0xF39C, 0x0000, 0x0000, 0x6300, 0xF18C, 0x8C63, 0x63F1, 0xF18C,   //  Data 50-57
    0x0000, 0x0000, 0x7F00, 0x7F7F, 0x7F7F, 0x7F7F, 0x7F7F, 0x007F,   //  Data 58-65
    0x0000, 0x0000, 0x0D0A, 0x4C52, 0x3230, 0x532D, 0x4D49, 0x4C55,   //  Data 66-73
    0x5441, 0x524F, 0x5620, 0x4E4F, 0x5220, 0x4945, 0x484E, 0x5241,   //  Data 74-81
    0x2044, 0x4548, 0x4255, 0x5245, 0x4547, 0x0A52, 0x520D, 0x304C,   //  Data 82-89
    0x2D32, 0x4953, 0x554D, 0x414C, 0x4F54, 0x2052, 0x4F56, 0x204E,   //  Data 90-97
    0x4552, 0x4E49, 0x4148, 0x4452, 0x4820, 0x5545, 0x4542, 0x4752,   //  Data 98-105
    0x5245, 0x0D0A, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 106-113
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF,   //  Data 114-121
    0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x00FF, 0x0000,                   //  Data 122-127
    0x3A33,                                                           //  Data 128 = CRC
    0x0000,                                                           //  129 = PD2
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  130-137=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,   //  138-145=Zero
    0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 }; //  146-153=Zero
  //
  //
  for (i = 0; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }             // clear buffer
  for (i = 0; i < 150; i++ ){ SECTOR.rl02i[i] = mysector[i]; }        // Load buffer
  //make_data_CRC();
    SECTOR.rl02l[100]=0x2E575757; // "WWW."
    SECTOR.rl02l[101]=0x31504450; // "PDP1"
    SECTOR.rl02l[102]=0x2E594731; // "1GY."
    SECTOR.rl02l[103]=0x204D4F43; // "COM "
    SECTOR.rl02l[127]=0x45444E45; // "ENDE" = Indicator
}
//
//
void make_header_CRC(void){
  unsigned short int DEVICE_CRC16 = 0;
  // Header - Word 1 of 3  ( data )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2],0xA001);   //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+1],0xA001); //LSB
  // Header - Word 2 of 3  ( always 0 )
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+2],0xA001); //HSB
  DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[header_index*2+3],0xA001); //LSB
  // Header - Word 3 of 3  -> Header-CRC
  SECTOR.rl02i[header_index+2]=DEVICE_CRC16;
}
//
//
void make_data_CRC(void){
  unsigned short int i, MSB, LSB;
  unsigned short int DEVICE_CRC16;
  //
  DEVICE_CRC16 = 0;                             // preset Data-CRC
  //
  for (i = data_start; i < data_CRC; i++ ){
    MSB = i<<1;      // = i*2
    LSB = MSB + 1;
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[MSB],0xA001);
    DEVICE_CRC16 = calcCRC16r(DEVICE_CRC16,SECTOR.rl02c[LSB],0xA001);
  }
  SECTOR.rl02i[data_CRC] = DEVICE_CRC16;       // SET DATA-CRC
}
//
//
void print_sector(void){
 int j;
 printf("\n\r------------------------------------------------------------------\n\r");
 for (j = 0; j < 256; j++ ) {
    printf("%c",SECTOR.rl02c[j]);
 }
 printf("\n\r------------------------------------------------------------------\n\r");
}
//
//
void make_bad_sector_file(void) {
// reconstruct error free RL Cartridge (EF)
   unsigned short int j = data_start, i=0;
   //
   SECTOR.rl02i[j]   = 0x2803;                           // 0,1 = Cartridge SN - My Birthday
   SECTOR.rl02i[j+1] = 0x1954;                           // 0,1 = Cartridge SN - in HEX notation
   SECTOR.rl02i[j+2] = 0x0000;                           // 2 = unused
   SECTOR.rl02i[j+3] = 0x0000;                           // 3 = Written with Zeros for Data Cartridge
   SECTOR.rl02i[j+4] = 0xFFFF;                           // 4 = Ones until End of sector = Error free
   for (i = j+4; i < 256; i++ ){
      if( i > data_start +128) {
      SECTOR.rl02i[i] = 0x000;
      } else {
      SECTOR.rl02i[i] = 0xFFFF;
     }
   }
   make_data_CRC();
}
//
//
void make_offline_track0(void) {
 // construct sector data  @ cylinder 0+1 and bad sector file into memory
 unsigned short int RL_sector,  RL_cylinder=0, i, temp;
 int nr = 0;
 printf ("\n\r              ******** OFFLINE MODE *******");
 printf ("\n\r              *  Construct cylinder 0 and *");
 printf ("\n\r              *    bad sector file only   *");
 printf ("\n\r              *****************************\n\r");
  //
  for (RL_cylinder = 0; RL_cylinder < 2; RL_cylinder++ ) {
  //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 0
      temp = 0;
      temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
      temp = temp | RL_sector;                          // Set RL01-Sector
      temp = temp &~0x40;                               // Clear = select head-0
      SECTOR.rl02i[header_index] = temp;                // >> SET <<
      make_header_CRC();                                // build header CRC
      //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
         make_bootsector();}
      for(i = 0; i< SEC_size_i; i++) {
          RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
      }
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
        PRESET_one_SECTOR(); }
      nr = nr + SEC_size_i;
    }
    //
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {     // construct 40 sectors @ head 1
        temp = 0;
      temp = RL_cylinder<<7;                             // Set RL-Cylinder address
      temp = temp | RL_sector;                           // Set RL-Sector
      temp = temp | 0x40;                                // Set = select head-1
      SECTOR.rl02i[header_index] = temp;                 // >> SET <<
      make_header_CRC();                                 // build header CRC
      for(i = 0; i< SEC_size_i; i++) {
         RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
      }
      nr = nr + SEC_size_i;
     }
   }
   //
   make_bad_sector_file();
   RL_cylinder = MAXCYL;
   nr = (SEC_size_i*80)*MAXCYL;                           // point to last,= bad sector Cylinder
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
}
//
//
void make_rl_structure_in_ram(void) {
// +
// construct full RL01/RL02 image in Memory ( union = SD RAM )
// the idea behind this routine is to dump the memory contents in pieces of 512 byte
// to the SD-Card after constructing the RL01 image in Memory.
// -
unsigned short int RL_sector, RL_cylinder, dot=0, led0=0x0001, led1=0x8000, i;
short int temp;
int nr=0;
 //printf("\n\r MAXCYL:   %d \r\n", MAXCYL);
 for (RL_cylinder = 0; RL_cylinder < MAXCYL; RL_cylinder++ ) {
  //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) { // construct 40 sectors @ head 0
      temp = 0;
      temp = RL_cylinder<<7;                            // Set RL-Cylinder address
      temp = temp | RL_sector;                          // Set RL-Sector
      temp = temp &~0x40;                               // Clear = select head-0
      SECTOR.rl02i[header_index] = temp;                // >> SET <<
      make_header_CRC();                                // build header CRC
      //if(RL_sector == 0){                             // >>>>> SET:  make sector 0 <<<<<<
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>>> SET:  make sector 0 <<<<<<
         make_bootsector();}
      for(i = 0; i< SEC_size_i; i++) {
          RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
      }
      if((RL_sector == 0) & (RL_cylinder == 0)){        // >>>> RESET: make sector 0 <<<<<<
        PRESET_one_SECTOR(); }
      nr = nr + SEC_size_i;
    }
    //
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led1);
    if(led1 == 0x0000){ led1=0x8000; } led1=led1>>1;
    //
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
      temp = RL_cylinder<<7;                             // Set RL-Cylinder address
      temp = temp | RL_sector;                           // Set RL-Sector
      temp = temp | 0x40;                                // Set = select head-1
      SECTOR.rl02i[header_index] = temp;                 // >> SET <<
      make_header_CRC();                                 // build header CRC
      for(i = 0; i< SEC_size_i; i++) {
         RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];     // Copy track into RAM
      }
      nr = nr + SEC_size_i;
     }
     if(dot >56){printf("\r*");dot=0;}else{printf("*");}dot++;
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led0);
     if(led0 == 0x0000){ led0=0x0001; } led0=led0<<1;
   }
   // RT-11 command to get contents of RL01 Bad Sector file: dump/term/only:23730 dl0:
   //
   make_bad_sector_file();
   //
   RL_cylinder = MAXCYL;                                  // point to last cylinder
   //
   for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {    // construct 40 sectors @ head 0
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL01-Cylinder address
        temp = temp | RL_sector;                          // Set RL01-Sector
        temp = temp &~0x40;                               // Clear = select head-0
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
    for (RL_sector = 0; RL_sector < 40; RL_sector++ ) {  // construct 40 sectors @ head 1
        temp = 0;
        temp = RL_cylinder<<7;                            // Set RL-Cylinder address
        temp = temp | RL_sector;                          // Set RL-Sector
        temp = temp | 0x40;                               // Set = select head-1
        SECTOR.rl02i[header_index] = temp;                // >> SET <<
        make_header_CRC();                                // build header CRC
        for(i = 0; i< SEC_size_i; i++) {
            RLDRIVE.rl_drive_i[nr+i] = SECTOR.rl02i[i];   // Copy track into RAM
        }
        nr = nr + SEC_size_i;
    }
 }
//
//
void make_bootsector(void) {
 short int i;
 unsigned short bootsector[]=
 { 0x00A0, 0x0005, 0x0104, 0x0000, 0x0000, 0x4310, 0x9C10, 0x0100,       // * ..........C....*
   0x0837, 0x0024, 0x000D, 0x0000, 0x0A00, 0x423F, 0x4F4F, 0x2D54,       // *7.$.......?BOOT-*
   0x2D55, 0x6F4E, 0x6220, 0x6F6F, 0x2074, 0x6E6F, 0x7620, 0x6C6F,       // *U-No boot on vol*
   0x6D75, 0x0D65, 0x0A0A, 0x0080, 0x8BDF, 0xFF74, 0x80FD, 0x941F,       // *ume....._.t.}...*
   0xFF76, 0x80FA, 0x01FF, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };     // *v.z.............*
  //
  for (i = data_start; i < 256; i++ ){ SECTOR.rl02i[i] = 0x0000; }       // clear data area
  for (i = 0; i < 40; i++){
   SECTOR.rl02i[i+data_start] = bootsector[i];                         // init Sector
  }
  make_data_CRC();
}
//
//
void WRITE_drive_to_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine writes one sector from union RLDRIVE.rl_drive_i to FPGA/DP-RAM
  //                               ####################
  //                               ### Union-->FPGA ###
  //                               ####################
  //
  mode = mode|0x0010;                                 // = WRITE to PORT A, bit05 = HIGH
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);      // SET
  //
  memcpy((void *)(DPRAM), &RLDRIVE.rl_drive_i[point_to_track], SEC_size_c * 40);
  //
  mode = mode&~0x0010;                                // = READ from  PORT A, bit05 = LOW
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);      // SET
}
//
//
void READ_drive_from_FPGA(int point_to_track){
  //
  // FPGA Dual-Ported-RAM size: 40 x SEC_size 16bit words = 5760 16bit words/track
  // This routine reads one sector from FPGA/DP-RAM into union RLDRIVE.rl_drive_i
  //                               ####################
  //                               ### FPGA-->Union ###
  //                               ####################
  //
  mode = mode&~0x0010;                                // = READ from PORT A, bit05 = LOW
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);      // SET
  //
  memcpy(&RLDRIVE.rl_drive_i[point_to_track], (void *)(DPRAM), SEC_size_c * 40);
  //
}
//
//
void get_header_infos(void) {
  short int i=0, j=0, k=0;
  printf ("\n\r++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
  for (i=0; i < 40; i++ ) {
    printf ("\n\r  ");
  for (k=0; k < 8; k++ ) {
    print_binary_16bit_LSB(RLDRIVE.rl_drive_i[j+k]);
      //LSB_print_binary_16bit(RLDRIVE.rl_drive_i[j+k]);
    printf ("  ");
  }
  j=j+SEC_size_i;
  }
  printf ("\n\r++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
}
//
//
void send_drive_info( unsigned short infodrive){
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, infodrive);                 // Preset PIO
}
//
//
void acknowledge(void){
  // Terminate Seek-cycle,  sending a acknowledge pulse  @ O_ctrl[2]
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode|0x0004));      // Set Acknowledge
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode&~0x0004));     // Clear Acknowledge
}
//
//
void check_SD_Card(void){
  DSTATUS DStatus;
  FRESULT FResult;
  //
  DStatus = disk_initialize(0);
  if (DStatus != 0){
    printf ("\n\r\x07 No SD card! Insert SD-Card & restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
  //
  FResult = f_mount(0, &Fatfs);
  if (FResult != FR_OK){
    printf ("\n\r\x07 No valid SD card! Restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
}
//
//
void make_FAT32_on_SD_Card(void){
  FRESULT FResult;
  FResult = f_mkfs(0, 0, 4096);
  if (FResult != FR_OK) {
    printf ("\n\r\x07 ERROR formatting SD-Card volume! Restart system  \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1);
  }else {
    printf(" "); }
}
//
//
void make_myfile_on_SD_Card(void){
  FRESULT FResult;
  FIL     hFile;
  TCHAR   Buffer[128];
  TCHAR   *pString;
  //
  FResult = f_open(&hFile, myfile1, FA_CREATE_ALWAYS | FA_WRITE);
  if (FResult != FR_OK) {
    printf ("\n\r\x07 ERROR No SD-Card write access! Restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1); }
  f_printf(&hFile,"\r\n       DE0-Nano FPGA based RL01/RL02 disk emulator");
  f_printf(&hFile, "\r\n        Copyright (C) 2017 by Reinhard Heuberger   ");
  f_printf(&hFile, "\r\n                http://www.pdp11gy.com/     \r\n");
   FResult = f_close(&hFile);
   //
   FResult = f_open(&hFile, myfile1 , FA_READ);
   if (FResult != FR_OK) {
     printf ("\n\r\x07 ERROR No SD-Card read access! Restart system \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
     while(1); }
   pString = f_gets(&Buffer[0], sizeof(Buffer), &hFile);
   while (pString != NULL){
   printf("%s", pString);
   pString = f_gets(&Buffer[0], sizeof(Buffer), &hFile);}
   FResult = f_close(&hFile);
}
//
//
void WRITE_to_SD_Card(void){
  //
  // RL01: 5,62 MB ( 5.898.752 Bytes)
  // RL02: 11,2 MB (11.796.992 Bytes)
  //
  //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
  //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) );
  //
  FRESULT FResult;
  FIL     hFile;
  uint32_t bytesWritten;
  int loops=SDRAM/20480, i=0, j=0;
  unsigned short dot=0, led=0x8000;
  //
  FResult = f_open(&hFile, myfile2, FA_CREATE_ALWAYS | FA_WRITE);
   if (FResult != FR_OK) {
   printf ("\n\r\x07 ERROR opening RL image-file! Restart system \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
   while(1);
   }
   i=0;
   for(j=0; j<loops; j++) {
     FResult = f_write(&hFile, (void*)&RLDRIVE.rl_drive_c[i], 20480, &bytesWritten );
     if (FResult != FR_OK) {
     printf ("\n\r\x07 ERROR writing to RL image-file! Restart system \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                        //$$
     while(1);}
     if(dot >56){printf("\r#");dot=0;}else{printf("#");}dot++;
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led);
     if(led == 0x0000){ led=0x8000; } led=led>>1;
     i=i+20480;
   }
   FResult = f_write(&hFile, (void*)&SECTOR.rl02c[0], 512, &bytesWritten  );
   //
   FResult = f_close(&hFile);
}
//
//
void READ_from_SD_Card(void){
  //
  // RL01: 5,62 MB ( 5.898.752 Bytes)
  // RL02: 11,2 MB (11.796.992 Bytes)
  //
  //int *my_BUFFER = (void*)&RLDRIVE.rl_drive_c[0];
  //printf(" size:  %d \n\r", (int)sizeof(RLDRIVE.rl_drive_c) )
  //
  FRESULT FResult;
  FIL     hFile;
  uint32_t bytesWritten;
  int loops=SDRAM/20480, i=0, j=0;
  unsigned short int dot=0, led=0x0001;
  //
  FResult = f_open(&hFile, myfile2, FA_READ);
  if (FResult != FR_OK) {
    printf ("\n\r\x07 ERROR opening RL image-file! Restart system \n\r");
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                           //$$
    while(1);
  }
  i=0;
  for(j=0; j<loops; j++) {
  FResult = f_read(&hFile, (void*)&RLDRIVE.rl_drive_c[i], 20480, &bytesWritten  );
    if (FResult != FR_OK) {
     printf ("\n\r\x07 ERROR reading from RL image-file! Restart system \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);                        //$$
     while(1);}
    if(dot >56){printf("\r.");dot=0;}else{printf(".");}dot++;
    IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, led);
    if(led == 0x0000){ led=0x0001; } led=led<<1;
    i=i+20480;
  }
  FResult = f_read(&hFile, (void*)&SECTOR.rl02c[0], 512, &bytesWritten );
  //
  FResult = f_close(&hFile);
}
//
//
//
//================================================================================================
//=============================================== main ===========================================
//================================================================================================
//
int main(void)
{
  int Cy_index = 0;                                  // Cylinder address @ SD-RAM
  int old_Cy_index = 0;                              // Saved Cylinder address @ SD-RAM
  int cylinder_address_phy=0;                        // Address @ SD-RAM 0- 2949120
  short int count=0;
  unsigned short int pio=0;
  unsigned short int cylinder_address_diff=0;
  unsigned short int head=0, old_head=0;
  unsigned short int rl_status;
  //int *RL02_SECTOR = u_rl02ptr->rl02l;                          // SECTOR-Pointer
  //int *RL02_CYLINDER = *u_rl02_drive_ptr->rl_drive_l;           // CYLINDER-Pointer
  //
  //
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, mode);                  // Clear PIO-0
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);                  // Clear PIO-1
  IoInit();
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x08)) {       // KEY_1 @ I_ctrl[3]
    RL = 1;                                                       // RL02
  } else {
    RL = 0;                                                       // RL01
  }
  //
  printf("\n\r\x1B[2J     ****** FPGA-based RL01/RL02 SIMULATOR  ******\n\r");
  printf("         DE0-Nano  based Emulator Version V.5.0               \n\r");
  printf("         *****************!********************               \n\r");
  //printf("              ...booted from EPC (V16.1)...                  \n\r");
  printf("         *****************!********************               \n\r");
  printf("         (c) Reinhard Heuberger WWW.PDP11GY.COM               \n\r");
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x0020)) {
    DEBUG = 1;
    printf ("\n\r              >>>>>> DEBUG-MODE = ON <<<<<<");
  } else {
    DEBUG = 0;
    printf ("\n\r              >>>>>> DEBUG-MODE = OFF <<<<<");
  }
  if (RL == FALSE){
    rl_status = RL01_OK;
    SDRAM = 5898240;
    MAXCYL = RL01_size;
    myfile2[3] = '1';
    printf ("\n\r              >>>>> Device Type = RL01 <<<<\n\r");
  } else {
    rl_status = RL02_OK;
    SDRAM = 11796480;
    MAXCYL = RL02_size;
    myfile2[3] = '2';
    printf ("\n\r              >>>>> Device Type = RL02 <<<<\n\r");
  }
  //
  RL_unit = (IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE)>>6) &~0xFFFC;
   switch(RL_unit) {
    case 0x0000: myfile2[5] = '0'; break;
    case 0x0001: myfile2[5] = '1'; break;
    case 0x0002: myfile2[5] = '2'; break;
    case 0x0003: myfile2[5] = '3'; break;
   }
   printf ("              >>>>> RL01/RL02 Unit:  %d <<<<\n\r",RL_unit);
  //
  //
  PRESET_one_SECTOR(); startup_leds();                                // First-INIT
  //if(DEBUG == TRUE) { print_sector(); }
  IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, count);                     // Clear PIO-0
  //
  //
  // A) Check for OFFLINE Mode ( SWITCH 01 @ I_ctrl[11] )
  if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x0800)) {
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);                 // LED Status indicator
     OFFLINE = 1;                                                     // OFFLINE-Mode
     make_offline_track0();                                           // construct one track in memory/union
      //make_rl_structure_in_ram();
  } else {
      OFFLINE = 0;                                                    // ONLINE-Mode
      printf ("\n\r              ******** ONLINE MODE ********\n\r");
      //
  // B) Check for SD card Format Request ( SWITCH 00 @ I_ctrl[2])
      check_SD_Card();                                                // Online mode only possible with SD-Card
      //
      if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04)) {       // (RE)Format SD card ?
        printf ("\n\r Construct RL01/RL02 cartridge format on SD_Card  \n\r");
        printf ("  Switch-1 is ON , Reformat SD-Card with FAT32    \n\r");
        printf ("       Insert SD-Card and reset Switch-0    \n\r\n");
        while (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x04));
        printf ("  Step 1 of 5 : Test interface ..... ");
      printf("done! \r\n");
      printf ("  Step 2 of 5 : Reformat SD-Card with FAT32... ");
      if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x0020)) {
        make_FAT32_on_SD_Card();
        printf ("done!\n\r");
      } else {
      printf("skiped\n\r"); }
      printf ("  Step 3 of 5 : Test SD-Card: ");
      make_myfile_on_SD_Card();
      printf ("Step 4 of 5 : Construct RL01/RL02 cartridge format in RAM \n\r");
      make_rl_structure_in_ram();
      printf ("\r\n  Step 5 of 5 : Dump RAM to SD-Card into file:");
      printf(" %s\n\r", myfile2 );
      PRESET_one_SECTOR();
      WRITE_to_SD_Card();
      }else {                                                           // Start normal
   // C) Check for connected RL controller , Power OK Signal @ I_ctrl[0]
          if (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x01)){
            IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);
            printf("\n\r\x07\x1B[2J");  // VT100 EScape Sequenze : Clear_screen
            printf("\n\r               System start not possible !      ");
            printf("\n\r              No connection to RL controller    ");
            printf("\n\r               Restart system and try again     ");
            while(1);
          } else {
          printf ("           Read SD-Card, file:  ");printf(" %s\n\r", myfile2 );
          READ_from_SD_Card();
           if (SECTOR.rl02l[127] != 0x45444E45 ) {
              printf("\n\n\rSD-Card with illegal format detected !");
              printf("\n\r               Restart system and try again     ");
              while(1);
           }
         }
      }
   }
   //
   //
   mode = 0x4001;                                           // = start conditions set up
   IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, mode);           // Start, Step #1of2 = ENABLE interface
   //
   //                                                             ####################
   WRITE_drive_to_FPGA(Cy_index);//                               ### Union-->FPGA ###
   //                                                             ####################
   //
   //==========================================================================================
   printf("\r\n ************ S T A R T RL01/RL02-Simulator ************* \n\r");
   //==========================================================================================
   send_drive_info(rl_status);
   IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, (mode=mode|0x00A0));    // Output Enable + Drive Ready
   if(DEBUG == TRUE) {
     printf(" Started with operating mode:            ");
     print_binary_16bit_LSB(mode);printf("    \r\n\n\n");
   }
   //
   //                                           ��������������������������
   while(1){       //                           �������  MAIN LOOP �������
    //                                          ��������������������������
    //
    // 1) check for drive command @ I_ctrl[1]
    if (( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x0002)) {              // test @ I_ctrl[1]
      pio = IORD_ALTERA_AVALON_PIO_DATA(PIO_0_BASE);                      // get command > pio
      if(DEBUG == TRUE){ printf("\n\rDrive command received: ");print_binary_16bit_LSB(pio);}
      if(RL == 0) {
        pio = pio &~0x8000;                                                // RL01 !!
        if(DEBUG == TRUE){ printf("\n\rDrive command modified: ");print_binary_16bit_LSB(pio);}
      }
      //-------------------------------------------------------------------------------------
      cylinder_address_diff = (pio >>7);                 // get Cylinder Address Difference
      if(pio & 0x0010){                                  // get head number & define offset
         head = DPR_size; } else { head = 0;             // Bit 04 = Head select
      if(DEBUG == TRUE) {
          printf("\n\r   cylinder address difference : %d ", cylinder_address_diff );
          printf(" with head: ");
          if(head == 0){ printf("0  "); } else { printf("1  ");}}
      }
      if(head == 0){
         rl_status = (rl_status &~ 0x0040);                       // Indicate: head 0 in use
        } else {
         rl_status = (rl_status |  0x0040);                       // indicate: head 1 in use
          }
      send_drive_info(rl_status);
      //
      if((cylinder_address_diff == 0) & (head == old_head)) {
         acknowledge();                                        // all done
         if(DEBUG == TRUE){printf("\n\r     Request with no action    ");}
      } else {
        if(DEBUG == TRUE){
        if((head != old_head) & (head == DPR_size)) {
          printf("\n\r >>> Switched to head 1   ");
        }
      }
                                                                // ####################
      READ_drive_from_FPGA(old_Cy_index + old_head );           // ### FPGA-->Union ###
                                                                // ####################
      if(pio & 0x0004){
               // 1= move heads toward spindle
         cylinder_address_phy = (cylinder_address_phy + cylinder_address_diff) ;
        } else {
         // 0= move heads away from spindle
         cylinder_address_phy = (cylinder_address_phy - cylinder_address_diff);
      }
      // Calculate index for SD RAM/union
      Cy_index = (cylinder_address_phy * CYL_size);
      if(DEBUG == TRUE) {
        printf("\n\r  New physical cylinder address:  %d ", cylinder_address_phy );
        printf("\n\r  Point to #sector @ SD-RAM:      %d ", Cy_index + head );
      }
      // restart cycle......
                                                                // ####################
      WRITE_drive_to_FPGA(Cy_index + head);                     // ### Union-->FPGA ###
                                                                // ####################
      old_head  = head;
      old_Cy_index = Cy_index;                                  // all done
      acknowledge();
      }
    }
      //
    // 2) check for power fail or reset
    if ( (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x8000)) |       // Reset @ I_ctrl[15]   ?
     (!( IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE ) & 0x01)) )     {      // Power-OK @ I_ctrl[0] ?
     while (!(IORD_ALTERA_AVALON_PIO_DATA(PIO_1_BASE) & 0x8000 ));      // Release Reset switch?
     if( OFFLINE == FALSE ) {
         printf("\x1B[2J\n\r\x07        ......... Shutting down system .........\n\r");
         //
         READ_drive_from_FPGA(head);                                    // FPGA-->Union
         Cy_index = 0;
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0000);               // Clear PIO-0
         IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);               // Clear PIO-1
         //....save
         WRITE_to_SD_Card();                                            // SAVE to SD-Card
         //
     } else {
       IOWR_ALTERA_AVALON_PIO_DATA(PIO_0_BASE, 0x0000);                 // Clear PIO-0
       IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0xC000);                 // Clear PIO-1
         printf("\x07\n\n\r    *** System switched down *** \n\r");
     }
     printf("\x07\n\r          Press RESET button for restart \n\r");
     IOWR_ALTERA_AVALON_PIO_DATA(PIO_1_BASE, 0x0000);
      while(1);
    }
   }
   return 0;
}
